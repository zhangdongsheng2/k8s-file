-- MySQL dump 10.13  Distrib 5.7.30, for Linux (x86_64)
--
-- Host: localhost    Database: ms_thirdparty_dev
-- ------------------------------------------------------
-- Server version	5.7.30-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ms_thirdparty_dev`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ms_thirdparty_dev` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `ms_thirdparty_dev`;

--
-- Table structure for table `DATABASECHANGELOG`
--

DROP TABLE IF EXISTS `DATABASECHANGELOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DATABASECHANGELOG` (
  `ID` varchar(255) NOT NULL,
  `AUTHOR` varchar(255) NOT NULL,
  `FILENAME` varchar(255) NOT NULL,
  `DATEEXECUTED` datetime NOT NULL,
  `ORDEREXECUTED` int(11) NOT NULL,
  `EXECTYPE` varchar(10) NOT NULL,
  `MD5SUM` varchar(35) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `COMMENTS` varchar(255) DEFAULT NULL,
  `TAG` varchar(255) DEFAULT NULL,
  `LIQUIBASE` varchar(20) DEFAULT NULL,
  `CONTEXTS` varchar(255) DEFAULT NULL,
  `LABELS` varchar(255) DEFAULT NULL,
  `DEPLOYMENT_ID` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `DATABASECHANGELOGLOCK`
--

DROP TABLE IF EXISTS `DATABASECHANGELOGLOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DATABASECHANGELOGLOCK` (
  `ID` int(11) NOT NULL,
  `LOCKED` bit(1) NOT NULL,
  `LOCKGRANTED` datetime DEFAULT NULL,
  `LOCKEDBY` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ali_message_sign`
--

DROP TABLE IF EXISTS `ali_message_sign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ali_message_sign` (
  `id` varchar(255) NOT NULL,
  `sing_name` varchar(255) NOT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `scenarios` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ali_message_template`
--

DROP TABLE IF EXISTS `ali_message_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ali_message_template` (
  `id` varchar(255) NOT NULL,
  `apply_desc` varchar(255) NOT NULL,
  `template_code` varchar(255) NOT NULL,
  `template_content` varchar(255) NOT NULL,
  `template_name` varchar(255) NOT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `template_type` varchar(255) NOT NULL,
  `var_desc` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `hibernate_sequence`
--

DROP TABLE IF EXISTS `hibernate_sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hibernate_sequence` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ms_oss_file`
--

DROP TABLE IF EXISTS `ms_oss_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ms_oss_file` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `is_del` tinyint(4) NOT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `e_tag` varchar(255) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_type` varchar(255) DEFAULT NULL,
  `oss_name` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Current Database: `ms_region_dev`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ms_region_dev` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `ms_region_dev`;

--
-- Table structure for table `DATABASECHANGELOG`
--

DROP TABLE IF EXISTS `DATABASECHANGELOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DATABASECHANGELOG` (
  `ID` varchar(255) NOT NULL,
  `AUTHOR` varchar(255) NOT NULL,
  `FILENAME` varchar(255) NOT NULL,
  `DATEEXECUTED` datetime NOT NULL,
  `ORDEREXECUTED` int(11) NOT NULL,
  `EXECTYPE` varchar(10) NOT NULL,
  `MD5SUM` varchar(35) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `COMMENTS` varchar(255) DEFAULT NULL,
  `TAG` varchar(255) DEFAULT NULL,
  `LIQUIBASE` varchar(20) DEFAULT NULL,
  `CONTEXTS` varchar(255) DEFAULT NULL,
  `LABELS` varchar(255) DEFAULT NULL,
  `DEPLOYMENT_ID` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `DATABASECHANGELOGLOCK`
--

DROP TABLE IF EXISTS `DATABASECHANGELOGLOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DATABASECHANGELOGLOCK` (
  `ID` int(11) NOT NULL,
  `LOCKED` bit(1) NOT NULL,
  `LOCKGRANTED` datetime DEFAULT NULL,
  `LOCKEDBY` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `region_dict`
--

DROP TABLE IF EXISTS `region_dict`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `region_dict` (
  `id` varchar(36) NOT NULL,
  `r_code` varchar(255) DEFAULT NULL,
  `r_level` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `parent_code` varchar(255) DEFAULT NULL,
  `parent_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKs3obxwi341nymh5kdfolygl50` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Current Database: `ms_common_dev`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ms_common_dev` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `ms_common_dev`;

--
-- Table structure for table `DATABASECHANGELOG`
--

DROP TABLE IF EXISTS `DATABASECHANGELOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DATABASECHANGELOG` (
  `ID` varchar(255) NOT NULL,
  `AUTHOR` varchar(255) NOT NULL,
  `FILENAME` varchar(255) NOT NULL,
  `DATEEXECUTED` datetime NOT NULL,
  `ORDEREXECUTED` int(11) NOT NULL,
  `EXECTYPE` varchar(10) NOT NULL,
  `MD5SUM` varchar(35) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `COMMENTS` varchar(255) DEFAULT NULL,
  `TAG` varchar(255) DEFAULT NULL,
  `LIQUIBASE` varchar(20) DEFAULT NULL,
  `CONTEXTS` varchar(255) DEFAULT NULL,
  `LABELS` varchar(255) DEFAULT NULL,
  `DEPLOYMENT_ID` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC
/*!50100 PARTITION BY KEY (ID)
(PARTITION p0 ENGINE = InnoDB,
 PARTITION p1 ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `DATABASECHANGELOGLOCK`
--

DROP TABLE IF EXISTS `DATABASECHANGELOGLOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DATABASECHANGELOGLOCK` (
  `ID` int(11) NOT NULL,
  `LOCKED` bit(1) NOT NULL,
  `LOCKGRANTED` datetime DEFAULT NULL,
  `LOCKEDBY` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC
/*!50100 PARTITION BY KEY ()
(PARTITION p0 ENGINE = InnoDB,
 PARTITION p1 ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ali_message_sign`
--

DROP TABLE IF EXISTS `ali_message_sign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ali_message_sign` (
  `id` varchar(255) NOT NULL,
  `sing_name` varchar(255) NOT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `scenarios` varchar(255) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC
/*!50100 PARTITION BY KEY ()
(PARTITION p0 ENGINE = InnoDB,
 PARTITION p1 ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ali_message_template`
--

DROP TABLE IF EXISTS `ali_message_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ali_message_template` (
  `id` varchar(255) NOT NULL,
  `apply_desc` varchar(255) NOT NULL,
  `template_code` varchar(255) NOT NULL,
  `template_content` varchar(255) NOT NULL,
  `template_name` varchar(255) NOT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `template_type` varchar(255) NOT NULL,
  `var_desc` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC
/*!50100 PARTITION BY KEY ()
(PARTITION p0 ENGINE = InnoDB,
 PARTITION p1 ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `hibernate_sequence`
--

DROP TABLE IF EXISTS `hibernate_sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hibernate_sequence` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ms_oss_file`
--

DROP TABLE IF EXISTS `ms_oss_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ms_oss_file` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `is_del` tinyint(4) NOT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `e_tag` varchar(255) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_type` varchar(255) DEFAULT NULL,
  `oss_name` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC
/*!50100 PARTITION BY KEY ()
(PARTITION p0 ENGINE = InnoDB,
 PARTITION p1 ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `region_dict`
--

DROP TABLE IF EXISTS `region_dict`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `region_dict` (
  `id` varchar(36) NOT NULL,
  `r_code` varchar(255) DEFAULT NULL,
  `r_level` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `parent_code` varchar(255) DEFAULT NULL,
  `parent_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FKs3obxwi341nymh5kdfolygl50` (`parent_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC
/*!50100 PARTITION BY KEY (id)
(PARTITION p0 ENGINE = InnoDB,
 PARTITION p1 ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Current Database: `ms_auth_dev`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ms_auth_dev` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `ms_auth_dev`;

--
-- Table structure for table `DATABASECHANGELOG`
--

DROP TABLE IF EXISTS `DATABASECHANGELOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DATABASECHANGELOG` (
  `ID` varchar(255) NOT NULL,
  `AUTHOR` varchar(255) NOT NULL,
  `FILENAME` varchar(255) NOT NULL,
  `DATEEXECUTED` datetime NOT NULL,
  `ORDEREXECUTED` int(11) NOT NULL,
  `EXECTYPE` varchar(10) NOT NULL,
  `MD5SUM` varchar(35) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `COMMENTS` varchar(255) DEFAULT NULL,
  `TAG` varchar(255) DEFAULT NULL,
  `LIQUIBASE` varchar(20) DEFAULT NULL,
  `CONTEXTS` varchar(255) DEFAULT NULL,
  `LABELS` varchar(255) DEFAULT NULL,
  `DEPLOYMENT_ID` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `DATABASECHANGELOGLOCK`
--

DROP TABLE IF EXISTS `DATABASECHANGELOGLOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DATABASECHANGELOGLOCK` (
  `ID` int(11) NOT NULL,
  `LOCKED` bit(1) NOT NULL,
  `LOCKGRANTED` datetime DEFAULT NULL,
  `LOCKEDBY` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `com_info`
--

DROP TABLE IF EXISTS `com_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `com_info` (
  `name` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `conf_seg_file`
--

DROP TABLE IF EXISTS `conf_seg_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conf_seg_file` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `file_content` longblob NOT NULL,
  `seg_crc` varchar(255) DEFAULT NULL,
  `seg_seq` int(11) DEFAULT NULL,
  `seg_size` int(11) DEFAULT NULL,
  `type` int(2) DEFAULT NULL,
  `fir_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKsuk4xpsohu5mnskekvjek8cg0` (`fir_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `device_alarm_log`
--

DROP TABLE IF EXISTS `device_alarm_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_alarm_log` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(8) DEFAULT NULL,
  `device_id` varchar(36) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `detail` varchar(500) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `edge_alarm_log`
--

DROP TABLE IF EXISTS `edge_alarm_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge_alarm_log` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(8) DEFAULT NULL,
  `edge_device_id` varchar(36) DEFAULT NULL,
  `edge_code` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `detail` varchar(500) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `platform_user`
--

DROP TABLE IF EXISTS `platform_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `platform_user` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `active_status` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `is_del` tinyint(4) NOT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `token` varchar(255) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_dvu76e8kc66ucv9xqo9e79b1o` (`username`),
  UNIQUE KEY `UK_rxsdcpvkgpth0kx9av8qnv26y` (`email`),
  UNIQUE KEY `UK_468k9l38f1u45vkhg3vytuf5` (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `platform_user_to_role`
--

DROP TABLE IF EXISTS `platform_user_to_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `platform_user_to_role` (
  `user_id` varchar(36) NOT NULL,
  `role_id` varchar(36) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `FKs177shlswlaoh5pec9uvsbga4` (`role_id`),
  CONSTRAINT `FKo617mioyd9if2xnpesaow37fa` FOREIGN KEY (`user_id`) REFERENCES `platform_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FKs177shlswlaoh5pec9uvsbga4` FOREIGN KEY (`role_id`) REFERENCES `sys_role` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `platform_user_token`
--

DROP TABLE IF EXISTS `platform_user_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `platform_user_token` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `device_no` varchar(255) DEFAULT NULL,
  `endpoint` varchar(255) DEFAULT NULL,
  `token` text,
  `user_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK7wxow64q545022ci46gff34jn` (`user_id`),
  CONSTRAINT `FK7wxow64q545022ci46gff34jn` FOREIGN KEY (`user_id`) REFERENCES `platform_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `saas_ds_info`
--

DROP TABLE IF EXISTS `saas_ds_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saas_ds_info` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `ds_driver` varchar(255) DEFAULT NULL,
  `ds_password` varchar(255) DEFAULT NULL,
  `ds_schema` varchar(255) DEFAULT NULL,
  `ds_status` int(11) DEFAULT NULL,
  `ds_username` varchar(255) DEFAULT NULL,
  `owner_id` varchar(36) DEFAULT NULL,
  `ds_deploy` varchar(255) DEFAULT NULL,
  `ds_platform` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FKrue7whmedj4rf53xm5gtp35mq` (`owner_id`) USING BTREE,
  CONSTRAINT `FKrue7whmedj4rf53xm5gtp35mq` FOREIGN KEY (`owner_id`) REFERENCES `tenant_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_menu`
--

DROP TABLE IF EXISTS `sys_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_menu` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `menu_code` varchar(255) DEFAULT NULL,
  `menu_desc` varchar(255) DEFAULT NULL,
  `menu_icon` varchar(255) DEFAULT NULL,
  `menu_name` varchar(255) DEFAULT NULL,
  `platform_id` varchar(255) DEFAULT NULL,
  `res_seq` int(11) DEFAULT NULL,
  `menu_type` varchar(255) NOT NULL,
  `parent_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_b679yhxaq3tpo2ri78i4tndgl` (`menu_code`),
  KEY `FK2jrf4gb0gjqi8882gxytpxnhe` (`parent_id`),
  CONSTRAINT `FK2jrf4gb0gjqi8882gxytpxnhe` FOREIGN KEY (`parent_id`) REFERENCES `sys_menu` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_menu_platform`
--

DROP TABLE IF EXISTS `sys_menu_platform`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_menu_platform` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `seq` int(11) NOT NULL,
  `parent_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_jy0xqcc9uvumjpdfrxk51tqjm` (`code`),
  KEY `FKmbbx8gnf8hq7ur2ojpsal1nup` (`parent_id`),
  CONSTRAINT `FKmbbx8gnf8hq7ur2ojpsal1nup` FOREIGN KEY (`parent_id`) REFERENCES `sys_menu_platform` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_menu_to_res`
--

DROP TABLE IF EXISTS `sys_menu_to_res`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_menu_to_res` (
  `menu_id` varchar(36) NOT NULL,
  `res_id` varchar(36) NOT NULL,
  PRIMARY KEY (`menu_id`,`res_id`),
  KEY `FKbhsi0cwtjjk7bmpoe911tebgc` (`res_id`),
  CONSTRAINT `FKbhsi0cwtjjk7bmpoe911tebgc` FOREIGN KEY (`res_id`) REFERENCES `sys_resource` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FKr4d1k0in09pd100stqmlwcefs` FOREIGN KEY (`menu_id`) REFERENCES `sys_menu` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_resource`
--

DROP TABLE IF EXISTS `sys_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_resource` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `res_code` varchar(255) DEFAULT NULL,
  `create_way` varchar(255) DEFAULT NULL,
  `has_path_var` int(11) DEFAULT NULL,
  `res_icon` varchar(255) DEFAULT NULL,
  `res_method` varchar(255) DEFAULT NULL,
  `res_name` varchar(255) DEFAULT NULL,
  `res_notes` varchar(255) DEFAULT NULL,
  `res_pass` bit(1) DEFAULT NULL,
  `res_portal` varchar(255) DEFAULT NULL,
  `res_service` varchar(255) DEFAULT NULL,
  `res_seq` int(11) DEFAULT NULL,
  `res_show` bit(1) DEFAULT NULL,
  `res_type` varchar(255) NOT NULL,
  `res_value` varchar(255) DEFAULT NULL,
  `parent_id` varchar(36) DEFAULT NULL,
  `res_level` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_c71kwhhpskpwvifk48ihjkapd` (`res_code`) USING BTREE,
  KEY `FK3fekum3ead5klp7y4lckn5ohi` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_role`
--

DROP TABLE IF EXISTS `sys_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_role` (
  `create_time` datetime(6) DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `role_code` varchar(255) NOT NULL,
  `role_desc` varchar(255) DEFAULT NULL,
  `role_is_system` bit(1) NOT NULL,
  `role_name` varchar(255) NOT NULL,
  `platform` varchar(255) DEFAULT NULL,
  `role_seq` int(11) DEFAULT NULL,
  `role_type` int(11) DEFAULT '0',
  `create_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_jqdita2l45v2gglry7bp8kl1f` (`role_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_role_to_menu`
--

DROP TABLE IF EXISTS `sys_role_to_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_role_to_menu` (
  `role_id` varchar(36) NOT NULL,
  `menu_id` varchar(36) NOT NULL,
  PRIMARY KEY (`role_id`,`menu_id`),
  KEY `FKs1jv484yyicnqdkaypu01gh5f` (`menu_id`),
  CONSTRAINT `FKcxv56j0m5l30ur60d8vhknowp` FOREIGN KEY (`role_id`) REFERENCES `sys_role` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FKs1jv484yyicnqdkaypu01gh5f` FOREIGN KEY (`menu_id`) REFERENCES `sys_menu` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_role_to_organize`
--

DROP TABLE IF EXISTS `sys_role_to_organize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_role_to_organize` (
  `role_id` varchar(36) NOT NULL,
  `organize_id` varchar(36) NOT NULL,
  PRIMARY KEY (`role_id`,`organize_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tenant_user`
--

DROP TABLE IF EXISTS `tenant_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tenant_user` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `active_status` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `employee_num` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `show_name` varchar(100) DEFAULT NULL,
  `user_type` int(11) DEFAULT '0',
  `web_chat` varchar(100) DEFAULT NULL,
  `is_force` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_c94csro6tfn98rkm5wrni7ixd` (`mobile`),
  UNIQUE KEY `UK_bjpignp2g82jcx943wawebole` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tenant_user_to_role`
--

DROP TABLE IF EXISTS `tenant_user_to_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tenant_user_to_role` (
  `user_id` varchar(36) NOT NULL,
  `role_id` varchar(36) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `FKcxrcilkya21lhwuprmg7imiql` (`role_id`),
  CONSTRAINT `FK18re3w0mryhjq52q2jgjps3f` FOREIGN KEY (`user_id`) REFERENCES `tenant_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FKcxrcilkya21lhwuprmg7imiql` FOREIGN KEY (`role_id`) REFERENCES `sys_role` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tenant_user_token`
--

DROP TABLE IF EXISTS `tenant_user_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tenant_user_token` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `endpoint` varchar(255) DEFAULT NULL,
  `token` text,
  `user_id` varchar(36) DEFAULT NULL,
  `device_no` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKsbd8c68pi1x7cxbb2nsqx0og0` (`user_id`),
  CONSTRAINT `FKsbd8c68pi1x7cxbb2nsqx0og0` FOREIGN KEY (`user_id`) REFERENCES `tenant_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Current Database: `ms_alarm_dev`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ms_alarm_dev` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `ms_alarm_dev`;

--
-- Table structure for table `DATABASECHANGELOG`
--

DROP TABLE IF EXISTS `DATABASECHANGELOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DATABASECHANGELOG` (
  `ID` varchar(255) NOT NULL,
  `AUTHOR` varchar(255) NOT NULL,
  `FILENAME` varchar(255) NOT NULL,
  `DATEEXECUTED` datetime NOT NULL,
  `ORDEREXECUTED` int(11) NOT NULL,
  `EXECTYPE` varchar(10) NOT NULL,
  `MD5SUM` varchar(35) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `COMMENTS` varchar(255) DEFAULT NULL,
  `TAG` varchar(255) DEFAULT NULL,
  `LIQUIBASE` varchar(20) DEFAULT NULL,
  `CONTEXTS` varchar(255) DEFAULT NULL,
  `LABELS` varchar(255) DEFAULT NULL,
  `DEPLOYMENT_ID` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `DATABASECHANGELOGLOCK`
--

DROP TABLE IF EXISTS `DATABASECHANGELOGLOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DATABASECHANGELOGLOCK` (
  `ID` int(11) NOT NULL,
  `LOCKED` bit(1) NOT NULL,
  `LOCKGRANTED` datetime DEFAULT NULL,
  `LOCKEDBY` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feed_alarm`
--

DROP TABLE IF EXISTS `feed_alarm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed_alarm` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `alarm_platform` varchar(255) DEFAULT NULL,
  `alarm_type` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `pool` int(11) DEFAULT NULL,
  `recover_type` varchar(255) DEFAULT NULL,
  `threshold` double DEFAULT NULL,
  `is_del` tinyint(4) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feed_alarm_associate`
--

DROP TABLE IF EXISTS `feed_alarm_associate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed_alarm_associate` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `device_name` varchar(255) DEFAULT NULL,
  `feed_id` varchar(255) DEFAULT NULL,
  `feed_name` varchar(255) DEFAULT NULL,
  `feed_prop` varchar(255) DEFAULT NULL,
  `instrument_id` varchar(255) DEFAULT NULL,
  `product_id` varchar(255) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `alarm_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKq23pr9we3vs85ax4f89w55fnk` (`alarm_id`),
  CONSTRAINT `FKq23pr9we3vs85ax4f89w55fnk` FOREIGN KEY (`alarm_id`) REFERENCES `feed_alarm` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feed_alarm_condition`
--

DROP TABLE IF EXISTS `feed_alarm_condition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed_alarm_condition` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `alarm_key` varchar(255) DEFAULT NULL,
  `alarm_value` double DEFAULT NULL,
  `alarm_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK2nrmovmdfn2lhvnehky1x3h4p` (`alarm_id`),
  CONSTRAINT `FK2nrmovmdfn2lhvnehky1x3h4p` FOREIGN KEY (`alarm_id`) REFERENCES `feed_alarm` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Current Database: `mqtt`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `mqtt` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `mqtt`;

--
-- Table structure for table `DATABASECHANGELOG`
--

DROP TABLE IF EXISTS `DATABASECHANGELOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DATABASECHANGELOG` (
  `ID` varchar(255) NOT NULL,
  `AUTHOR` varchar(255) NOT NULL,
  `FILENAME` varchar(255) NOT NULL,
  `DATEEXECUTED` datetime NOT NULL,
  `ORDEREXECUTED` int(11) NOT NULL,
  `EXECTYPE` varchar(10) NOT NULL,
  `MD5SUM` varchar(35) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `COMMENTS` varchar(255) DEFAULT NULL,
  `TAG` varchar(255) DEFAULT NULL,
  `LIQUIBASE` varchar(20) DEFAULT NULL,
  `CONTEXTS` varchar(255) DEFAULT NULL,
  `LABELS` varchar(255) DEFAULT NULL,
  `DEPLOYMENT_ID` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `DATABASECHANGELOGLOCK`
--

DROP TABLE IF EXISTS `DATABASECHANGELOGLOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DATABASECHANGELOGLOCK` (
  `ID` int(11) NOT NULL,
  `LOCKED` bit(1) NOT NULL,
  `LOCKGRANTED` datetime DEFAULT NULL,
  `LOCKEDBY` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mqtt_acl`
--

DROP TABLE IF EXISTS `mqtt_acl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mqtt_acl` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `allow` int(1) DEFAULT NULL COMMENT '0: deny, 1: allow',
  `ip_addr` varchar(60) DEFAULT NULL COMMENT 'IpAddress',
  `user_name` varchar(100) DEFAULT NULL COMMENT 'Username',
  `client_id` varchar(100) DEFAULT NULL COMMENT 'ClientId',
  `access` int(2) NOT NULL COMMENT '1: subscribe, 2: publish, 3: pubsub',
  `topic` varchar(100) NOT NULL DEFAULT '' COMMENT 'Topic Filter',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12778 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mqtt_user`
--

DROP TABLE IF EXISTS `mqtt_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mqtt_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `is_superuser` tinyint(1) DEFAULT '0',
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mqtt_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Current Database: `lrd_devops`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `lrd_devops` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `lrd_devops`;

--
-- Table structure for table `build_info`
--

DROP TABLE IF EXISTS `build_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `build_info` (
  `id` varchar(36) NOT NULL,
  `build_no` varchar(255) DEFAULT NULL,
  `commit_hash` varchar(255) DEFAULT NULL,
  `error_cnt` int(11) NOT NULL,
  `job` varchar(255) DEFAULT NULL,
  `log_time` datetime DEFAULT NULL,
  `mr_id` varchar(255) DEFAULT NULL,
  `p_id` varchar(255) DEFAULT NULL,
  `result` varchar(255) DEFAULT NULL,
  `warn_cnt` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `code_line_change`
--

DROP TABLE IF EXISTS `code_line_change`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `code_line_change` (
  `id` varchar(36) NOT NULL,
  `c_add` int(11) DEFAULT NULL,
  `c_author` varchar(255) DEFAULT NULL,
  `c_cal` int(11) DEFAULT NULL,
  `c_del` int(11) DEFAULT NULL,
  `log_time` datetime DEFAULT NULL,
  `mr_id` varchar(255) DEFAULT NULL,
  `p_id` varchar(255) DEFAULT NULL,
  `c_total` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Current Database: `iothub_dev`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `iothub_dev` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `iothub_dev`;

--
-- Table structure for table `DATABASECHANGELOG`
--

DROP TABLE IF EXISTS `DATABASECHANGELOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DATABASECHANGELOG` (
  `ID` varchar(255) NOT NULL,
  `AUTHOR` varchar(255) NOT NULL,
  `FILENAME` varchar(255) NOT NULL,
  `DATEEXECUTED` datetime NOT NULL,
  `ORDEREXECUTED` int(11) NOT NULL,
  `EXECTYPE` varchar(10) NOT NULL,
  `MD5SUM` varchar(35) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `COMMENTS` varchar(255) DEFAULT NULL,
  `TAG` varchar(255) DEFAULT NULL,
  `LIQUIBASE` varchar(20) DEFAULT NULL,
  `CONTEXTS` varchar(255) DEFAULT NULL,
  `LABELS` varchar(255) DEFAULT NULL,
  `DEPLOYMENT_ID` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `DATABASECHANGELOGLOCK`
--

DROP TABLE IF EXISTS `DATABASECHANGELOGLOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DATABASECHANGELOGLOCK` (
  `ID` int(11) NOT NULL,
  `LOCKED` bit(1) NOT NULL,
  `LOCKGRANTED` datetime DEFAULT NULL,
  `LOCKEDBY` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `activity_info`
--

DROP TABLE IF EXISTS `activity_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_info` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `activity_time` datetime(6) DEFAULT NULL,
  `activity_type` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `content` longtext,
  `is_del` tinyint(4) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `star` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC
/*!50100 PARTITION BY KEY ()
(PARTITION p0 ENGINE = InnoDB,
 PARTITION p1 ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `attr_unit`
--

DROP TABLE IF EXISTS `attr_unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attr_unit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `u_level` int(11) NOT NULL,
  `u_rate` varchar(255) DEFAULT NULL,
  `unit` varchar(255) NOT NULL,
  `u_type` varchar(255) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKaw7mr46b1qou05wxkmv6o47kk` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=110040 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `back_door`
--

DROP TABLE IF EXISTS `back_door`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `back_door` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bsn_schema`
--

DROP TABLE IF EXISTS `bsn_schema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bsn_schema` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `ds_schema` varchar(255) DEFAULT NULL,
  `bsn` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `UK_61d0c7nvrrsei7r8ohsb50tb0` (`bsn`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `business_reg_info`
--

DROP TABLE IF EXISTS `business_reg_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_reg_info` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `business_scope` text,
  `business_term` varchar(255) DEFAULT NULL,
  `credit_code` varchar(255) DEFAULT NULL,
  `enterprise_type` varchar(255) DEFAULT NULL,
  `legal_rep` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `reg_addr` varchar(255) DEFAULT NULL,
  `reg_capital` varchar(255) DEFAULT NULL,
  `reg_date` date DEFAULT NULL,
  `reg_office` varchar(255) DEFAULT NULL,
  `service_provider_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FKeyymkvahtsmk6cfreqstnae7q` (`service_provider_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC
/*!50100 PARTITION BY KEY ()
(PARTITION p0 ENGINE = InnoDB,
 PARTITION p1 ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cfg_file_to_comm_file`
--

DROP TABLE IF EXISTS `cfg_file_to_comm_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cfg_file_to_comm_file` (
  `cfg_file_id` varchar(36) NOT NULL,
  `comm_file_id` varchar(36) NOT NULL,
  PRIMARY KEY (`cfg_file_id`,`comm_file_id`),
  KEY `FK3dhh4x57vhr49p0fw5xhocalu` (`comm_file_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `check_record`
--

DROP TABLE IF EXISTS `check_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `check_record` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `retry_count` int(11) DEFAULT NULL COMMENT '重试次数',
  `is_success` tinyint(4) DEFAULT NULL COMMENT '是否成功',
  `check_date` date DEFAULT NULL COMMENT '被校准的日期',
  `data_source` varchar(255) DEFAULT NULL COMMENT '数据源',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `comm_file`
--

DROP TABLE IF EXISTS `comm_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comm_file` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `file_content` longblob NOT NULL,
  `file_content_type` varchar(255) DEFAULT NULL,
  `file_fullname` varchar(255) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_size` bigint(20) DEFAULT NULL,
  `file_status` int(11) DEFAULT NULL,
  `file_suffix` varchar(255) DEFAULT NULL,
  `file_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `common_question`
--

DROP TABLE IF EXISTS `common_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_question` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `ps_desc` text,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC
/*!50100 PARTITION BY KEY ()
(PARTITION p0 ENGINE = InnoDB,
 PARTITION p1 ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `config_file_list`
--

DROP TABLE IF EXISTS `config_file_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config_file_list` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `config_ver` varchar(255) NOT NULL,
  `is_valid` int(11) DEFAULT NULL,
  `iot_device_id` varchar(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1xs7pkmbuiyxi788kc692n5hj` (`iot_device_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `config_update_record`
--

DROP TABLE IF EXISTS `config_update_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config_update_record` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `new_ver` varchar(255) DEFAULT NULL,
  `old_ver` varchar(255) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `update_status` varchar(255) DEFAULT NULL,
  `time_end` datetime(6) DEFAULT NULL,
  `time_start` datetime(6) DEFAULT NULL,
  `iot_device_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKjmvbafjradxdjdcm59rt06h7` (`iot_device_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `config_update_record_item`
--

DROP TABLE IF EXISTS `config_update_record_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config_update_record_item` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `i_desc` varchar(255) DEFAULT NULL,
  `i_version` varchar(255) DEFAULT NULL,
  `i_step` varchar(255) DEFAULT NULL,
  `i_time` datetime(6) DEFAULT NULL,
  `record_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKbwwrr33oqionl38xwcnmibtkl` (`record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `consultation`
--

DROP TABLE IF EXISTS `consultation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consultation` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `cancel_time` datetime(6) DEFAULT NULL,
  `content` varchar(255) NOT NULL,
  `interested_prod` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `reply_date` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC
/*!50100 PARTITION BY KEY ()
(PARTITION p0 ENGINE = InnoDB,
 PARTITION p1 ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `data_up_error`
--

DROP TABLE IF EXISTS `data_up_error`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_up_error` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `product_id` varchar(255) DEFAULT NULL,
  `sn` varchar(255) DEFAULT NULL,
  `sn_type` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `topic` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `device_virtual_feed`
--

DROP TABLE IF EXISTS `device_virtual_feed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_virtual_feed` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `interval_unit_type` varchar(255) DEFAULT NULL,
  `interval_value` int(11) DEFAULT NULL,
  `monitor_prop` varchar(255) DEFAULT NULL,
  `result_feed_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elec_comsumption`
--

DROP TABLE IF EXISTS `elec_comsumption`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elec_comsumption` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `addr` varchar(255) NOT NULL,
  `charge_way` varchar(255) NOT NULL,
  `ent_code` varchar(255) DEFAULT NULL,
  `inlet_voltage` varchar(255) NOT NULL,
  `install_capacity` varchar(255) NOT NULL,
  `main_trans_num` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `electricity_rule`
--

DROP TABLE IF EXISTS `electricity_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `electricity_rule` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `rules` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `environment_info`
--

DROP TABLE IF EXISTS `environment_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `environment_info` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `config_ok` int(11) DEFAULT NULL,
  `config_version` varchar(255) DEFAULT NULL,
  `data_format` varchar(255) DEFAULT NULL,
  `device_name` varchar(255) DEFAULT NULL,
  `device_secret` varchar(255) DEFAULT NULL,
  `firmware_ok` int(11) DEFAULT NULL,
  `firmware_version` varchar(255) NOT NULL,
  `mqtt_ip` varchar(255) DEFAULT NULL,
  `mqtt_port` varchar(255) DEFAULT NULL,
  `on_time` int(11) DEFAULT NULL,
  `product_key` varchar(255) DEFAULT NULL,
  `product_secret` varchar(255) DEFAULT NULL,
  `send_interval` int(11) DEFAULT NULL,
  `sn` varchar(255) DEFAULT NULL,
  `sn_activate_flag` int(11) DEFAULT NULL,
  `sn_config_flag` int(11) DEFAULT NULL,
  `type_ok` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `factor_item`
--

DROP TABLE IF EXISTS `factor_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factor_item` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `compute_value` varchar(255) DEFAULT NULL,
  `log_to_feed_name` varchar(255) DEFAULT NULL,
  `log_to_feed_type` varchar(255) DEFAULT NULL,
  `operator` varchar(255) DEFAULT NULL,
  `operator_type` varchar(255) DEFAULT NULL,
  `seq` int(11) NOT NULL,
  `value` double DEFAULT NULL,
  `compute_input_id` varchar(36) DEFAULT NULL,
  `factor_type_id` varchar(36) DEFAULT NULL,
  `feed_id` varchar(36) DEFAULT NULL,
  `input_id` varchar(36) DEFAULT NULL,
  `log_to_feed_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3kryw6umw6u7ojl5y5fqmjxye` (`compute_input_id`),
  KEY `FK9hyi8t0nkricis6kkmuh4pfhu` (`factor_type_id`),
  KEY `FKrddfdi06i7t8nmdxe3eocq3ih` (`feed_id`),
  KEY `FKg7t6egoi32k258jq87u5q93bu` (`input_id`),
  KEY `FK3wl11tgtfrsm1cp5bx9ppvp21` (`log_to_feed_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `factor_type`
--

DROP TABLE IF EXISTS `factor_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factor_type` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `factor_code` varchar(255) DEFAULT NULL,
  `factor_desc` varchar(255) DEFAULT NULL,
  `feed_id` varchar(255) DEFAULT NULL,
  `feed_name` varchar(255) DEFAULT NULL,
  `feed_unit` varchar(255) DEFAULT NULL,
  `factor_name` varchar(255) DEFAULT NULL,
  `factor_title` varchar(255) DEFAULT NULL,
  `item_value` decimal(19,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feed`
--

DROP TABLE IF EXISTS `feed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `feed_id` varchar(255) DEFAULT NULL,
  `feed_log_value_type` varchar(45) DEFAULT NULL,
  `feed_num` varchar(255) DEFAULT NULL,
  `feed_type` varchar(255) DEFAULT NULL,
  `feed_value_type` varchar(255) DEFAULT NULL,
  `formula` varchar(255) DEFAULT NULL,
  `inst_id` varchar(255) DEFAULT NULL,
  `interval_unit_type` varchar(45) DEFAULT NULL,
  `interval_value` int(11) DEFAULT NULL,
  `is_auto` bit(1) DEFAULT NULL,
  `last_value` varchar(255) DEFAULT NULL,
  `monitory_prop_code` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `num` int(11) NOT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `unit_id` varchar(36) DEFAULT NULL,
  `update_time` datetime(6) DEFAULT NULL,
  `value_time` datetime(6) DEFAULT NULL,
  `input_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKimcpat0ihf1mbs5r983pmsrd4` (`input_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feed_compute`
--

DROP TABLE IF EXISTS `feed_compute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed_compute` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `feed_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feed_expression_variable`
--

DROP TABLE IF EXISTS `feed_expression_variable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed_expression_variable` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `expression` varchar(255) DEFAULT NULL,
  `feed_id` varchar(255) DEFAULT NULL,
  `place` varchar(255) DEFAULT NULL,
  `result_feed_id` varchar(255) DEFAULT NULL,
  `variable` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feed_factor_item`
--

DROP TABLE IF EXISTS `feed_factor_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed_factor_item` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `compute_feed_id` varchar(255) DEFAULT NULL,
  `compute_value` varchar(255) DEFAULT NULL,
  `feed_id` varchar(255) DEFAULT NULL,
  `operator` varchar(255) DEFAULT NULL,
  `operator_type` varchar(255) DEFAULT NULL,
  `seq` int(11) NOT NULL,
  `value` double DEFAULT NULL,
  `variable` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feed_formula_template`
--

DROP TABLE IF EXISTS `feed_formula_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed_formula_template` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `feed_name` varchar(255) DEFAULT NULL,
  `feed_value_type` varchar(255) DEFAULT NULL,
  `interval_unit_type` varchar(255) DEFAULT NULL,
  `interval_value` int(11) DEFAULT NULL,
  `template_id` varchar(255) DEFAULT NULL,
  `unit_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feed_task`
--

DROP TABLE IF EXISTS `feed_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed_task` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `feed_ids` varchar(255) NOT NULL,
  `interval_value` bigint(20) DEFAULT NULL,
  `task_name` varchar(255) DEFAULT NULL,
  `tenant_schema` varchar(255) DEFAULT NULL,
  `update_time` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_r6ipu0nkg6tf0fm3iprub1k1v` (`interval_value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feed_value`
--

DROP TABLE IF EXISTS `feed_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed_value` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `feed_id` varchar(255) DEFAULT NULL,
  `value` double DEFAULT NULL,
  `value_time` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feed_value_daily`
--

DROP TABLE IF EXISTS `feed_value_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed_value_daily` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `feed_id` varchar(255) DEFAULT NULL,
  `max_min_value_time` datetime(6) DEFAULT NULL,
  `value` double DEFAULT NULL,
  `value_time` date DEFAULT NULL,
  `value_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feed_value_hourly`
--

DROP TABLE IF EXISTS `feed_value_hourly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed_value_hourly` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `feed_id` varchar(255) DEFAULT NULL,
  `max_min_value_time` datetime(6) DEFAULT NULL,
  `value` double DEFAULT NULL,
  `value_time` datetime(6) DEFAULT NULL,
  `value_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feed_value_log_schedule`
--

DROP TABLE IF EXISTS `feed_value_log_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed_value_log_schedule` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `feed_id` varchar(255) NOT NULL,
  `feed_schedule_unit_type` varchar(255) DEFAULT NULL,
  `feed_value_type` varchar(255) DEFAULT NULL,
  `hour` int(11) DEFAULT NULL,
  `interval_hour` int(11) DEFAULT NULL,
  `interval_unit_type` varchar(255) DEFAULT NULL,
  `interval_value` int(11) DEFAULT NULL,
  `log_feed_id` varchar(255) NOT NULL,
  `tenant_schema` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `firmware_update_record`
--

DROP TABLE IF EXISTS `firmware_update_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `firmware_update_record` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `end_time` datetime(6) DEFAULT NULL,
  `new_ver` varchar(255) DEFAULT NULL,
  `old_ver` varchar(255) DEFAULT NULL,
  `rec_reason` varchar(255) DEFAULT NULL,
  `start_time` datetime(6) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `device_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK5upa7g40i0474duu9kvsoou4t` (`device_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `firmware_update_record_item`
--

DROP TABLE IF EXISTS `firmware_update_record_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `firmware_update_record_item` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `i_desc` varchar(255) DEFAULT NULL,
  `i_version` varchar(255) DEFAULT NULL,
  `i_step` varchar(255) DEFAULT NULL,
  `i_time` datetime(6) DEFAULT NULL,
  `record_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKi4vmt6p65s5qyynyulem0gjqa` (`record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `formula_template`
--

DROP TABLE IF EXISTS `formula_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `formula_template` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `expression` varchar(255) DEFAULT NULL,
  `factor_item_list` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `product_id` varchar(255) DEFAULT NULL,
  `prop` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `graph`
--

DROP TABLE IF EXISTS `graph`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `graph` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `end_time` datetime(6) DEFAULT NULL,
  `feed_id` varchar(255) DEFAULT NULL,
  `fill_color` varchar(255) DEFAULT NULL,
  `graph_name` varchar(255) DEFAULT NULL,
  `graph_type` varchar(255) DEFAULT NULL,
  `inst_id` varchar(255) DEFAULT NULL,
  `iot_device_id` varchar(255) DEFAULT NULL,
  `iot_product_id` varchar(255) DEFAULT NULL,
  `is_fill` bit(1) DEFAULT NULL,
  `start_time` datetime(6) DEFAULT NULL,
  `time_type` varchar(255) DEFAULT NULL,
  `y_max_val` varchar(255) DEFAULT NULL,
  `y_min_val` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `input`
--

DROP TABLE IF EXISTS `input`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `input` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `expression` varchar(255) DEFAULT NULL,
  `inst_addr` varchar(255) DEFAULT NULL,
  `inst_id` varchar(255) DEFAULT NULL,
  `inst_type` varchar(255) DEFAULT NULL,
  `prop` varchar(255) DEFAULT NULL,
  `prop_name` varchar(255) DEFAULT NULL,
  `property_code` varchar(255) DEFAULT NULL,
  `property_name` varchar(255) DEFAULT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `unit_code` varchar(255) DEFAULT NULL,
  `unit_id` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `value_time` datetime(6) DEFAULT NULL,
  `topic_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3ve3064u5p8ut0bamxjxgha1r` (`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `input_formula_template`
--

DROP TABLE IF EXISTS `input_formula_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `input_formula_template` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `input_id` varchar(255) DEFAULT NULL,
  `template_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `instrument`
--

DROP TABLE IF EXISTS `instrument`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instrument` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `addr` varchar(255) DEFAULT NULL,
  `device_id` varchar(255) NOT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `sn_type` varchar(255) DEFAULT NULL,
  `topic_id` varchar(255) NOT NULL,
  `type` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `instrument_prop_code_name`
--

DROP TABLE IF EXISTS `instrument_prop_code_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instrument_prop_code_name` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_5qvw5lhsdk50wwm1d9h4o6pni` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `iot_device`
--

DROP TABLE IF EXISTS `iot_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iot_device` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `active_status` varchar(255) DEFAULT NULL,
  `active_time` datetime(6) DEFAULT NULL,
  `adjust_status` varchar(255) DEFAULT NULL,
  `config_file_ver` varchar(255) DEFAULT NULL,
  `firmware_update_status` varchar(255) DEFAULT NULL,
  `firmware_ver` varchar(255) DEFAULT NULL,
  `ip_addr` varchar(255) DEFAULT NULL,
  `is_del` tinyint(4) NOT NULL,
  `keep_online_or_offline_time` datetime(6) DEFAULT NULL,
  `last_online_time` datetime(6) DEFAULT NULL,
  `dev_name` varchar(255) NOT NULL,
  `note_name` varchar(255) DEFAULT NULL,
  `secret` varchar(255) DEFAULT NULL,
  `dev_seri_no` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `status_update_time` datetime(6) DEFAULT NULL,
  `iot_product_id` varchar(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK48ophw25a6jkn33n5n7rdm0xi` (`iot_product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `iot_device_shadow`
--

DROP TABLE IF EXISTS `iot_device_shadow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iot_device_shadow` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `shadow` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `update_time` datetime(6) DEFAULT NULL,
  `device_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKr4iqc0nrymmshbtdeeaepohun` (`device_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `iot_product`
--

DROP TABLE IF EXISTS `iot_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iot_product` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `prod_desc` varchar(255) DEFAULT NULL,
  `is_del` tinyint(4) NOT NULL,
  `prod_key` varchar(255) DEFAULT NULL,
  `prod_name` varchar(255) NOT NULL,
  `node_type` varchar(255) DEFAULT NULL,
  `prod_category_id` varchar(255) NOT NULL,
  `prod_secret` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `job_config`
--

DROP TABLE IF EXISTS `job_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_config` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `data_source` varchar(255) DEFAULT NULL COMMENT '数据源',
  `up_time` date DEFAULT NULL COMMENT '正式使用时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `job_record`
--

DROP TABLE IF EXISTS `job_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_record` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `data_source` varchar(255) DEFAULT NULL COMMENT '数据源',
  `end_time` datetime DEFAULT NULL COMMENT '截止时间',
  `error_msg` text COMMENT '错误信息提示',
  `retry_count` int(11) DEFAULT NULL COMMENT '重试次数',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `is_success` tinyint(4) DEFAULT NULL COMMENT '是否成功',
  `retry_skip` varchar(45) DEFAULT NULL COMMENT '跳过重试',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `key_schema`
--

DROP TABLE IF EXISTS `key_schema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `key_schema` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `prod_key` varchar(255) DEFAULT NULL,
  `ds_schema` varchar(255) DEFAULT NULL,
  `dev_seri_no` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_61d0c7nvrrsei7r8ohsb50tb0` (`dev_seri_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mainstays`
--

DROP TABLE IF EXISTS `mainstays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mainstays` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `parent_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKey362h3nwshbvtjqr76wcky2f` (`parent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `manual_category`
--

DROP TABLE IF EXISTS `manual_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manual_category` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC
/*!50100 PARTITION BY KEY ()
(PARTITION p0 ENGINE = InnoDB,
 PARTITION p1 ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `manual_category_to_opt_mannual`
--

DROP TABLE IF EXISTS `manual_category_to_opt_mannual`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manual_category_to_opt_mannual` (
  `manual_category_id` varchar(36) NOT NULL,
  `opt_mannual_id` varchar(36) NOT NULL,
  PRIMARY KEY (`manual_category_id`,`opt_mannual_id`) USING BTREE,
  KEY `FK2fl8j1m19tpihlsvh7etekdkt` (`opt_mannual_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC
/*!50100 PARTITION BY KEY ()
(PARTITION p0 ENGINE = InnoDB,
 PARTITION p1 ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `monitoring_properties`
--

DROP TABLE IF EXISTS `monitoring_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `monitoring_properties` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `first_unit` varchar(255) DEFAULT NULL,
  `property_code` varchar(255) DEFAULT NULL,
  `property_name` varchar(255) NOT NULL,
  `property_system` varchar(255) DEFAULT NULL,
  `property_type` varchar(255) DEFAULT NULL,
  `second_unit` varchar(255) DEFAULT NULL,
  `symbol` varchar(255) DEFAULT NULL,
  `property_name_en` varchar(255) DEFAULT NULL,
  `property_code_short` varchar(50) DEFAULT NULL,
  `property_desc` varchar(1000) DEFAULT NULL,
  `property_parent` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `opt_manual`
--

DROP TABLE IF EXISTS `opt_manual`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `opt_manual` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `doc_url` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC
/*!50100 PARTITION BY KEY ()
(PARTITION p0 ENGINE = InnoDB,
 PARTITION p1 ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organizations`
--

DROP TABLE IF EXISTS `organizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organizations` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `mainstay_id` varchar(36) DEFAULT NULL,
  `parent_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK6yevr6xuwsittmrmb5ptjqxfx` (`mainstay_id`),
  KEY `FKgsay2unfbsax6k1ulw0k557o7` (`parent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ota_firmware_info`
--

DROP TABLE IF EXISTS `ota_firmware_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ota_firmware_info` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `fir_alg` varchar(255) NOT NULL,
  `fir_check_result` varchar(255) DEFAULT NULL,
  `fir_checksum` varchar(255) NOT NULL,
  `fir_cust_version` varchar(255) NOT NULL,
  `fir_desc` varchar(100) DEFAULT NULL,
  `fir_en` varchar(255) NOT NULL,
  `fir_file_id` varchar(255) NOT NULL,
  `fir_seq_cnt` int(11) DEFAULT NULL,
  `prod_id` varchar(36) DEFAULT NULL,
  `fir_name` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKyruj7vawy1imc76rgruqdkaj` (`prod_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ota_seg_file`
--

DROP TABLE IF EXISTS `ota_seg_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ota_seg_file` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `file_content` longblob NOT NULL,
  `seg_crc` varchar(255) DEFAULT NULL,
  `seg_crc_len` int(11) DEFAULT NULL,
  `seg_seq` int(11) DEFAULT NULL,
  `seg_size` int(11) DEFAULT NULL,
  `fir_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKsuk4xpsohu5mnskekvjek8cg0` (`fir_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `platform_user`
--

DROP TABLE IF EXISTS `platform_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `platform_user` (
  `id` varchar(36) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `is_del` tinyint(4) NOT NULL,
  `is_forbidden` tinyint(4) NOT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_dvu76e8kc66ucv9xqo9e79b1o` (`username`),
  UNIQUE KEY `UK_rxsdcpvkgpth0kx9av8qnv26y` (`email`),
  UNIQUE KEY `UK_468k9l38f1u45vkhg3vytuf5` (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `process_step_topic`
--

DROP TABLE IF EXISTS `process_step_topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_step_topic` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `process_type` varchar(255) DEFAULT NULL,
  `push_type` varchar(255) DEFAULT NULL,
  `step` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `topic_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product_category`
--

DROP TABLE IF EXISTS `product_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_category` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `cate_name` varchar(255) NOT NULL,
  `cate_seq` int(11) DEFAULT NULL,
  `parent_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_49vqy109pr85q1bi0k2ydlat8` (`cate_name`),
  KEY `FKlkvy3axep0ba8ccvrvfoyrfu4` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product_template`
--

DROP TABLE IF EXISTS `product_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_template` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `is_del` tinyint(4) NOT NULL,
  `prod_template_name` varchar(255) NOT NULL,
  `prod_category_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKi6ekcrh89aevu1sh4e4fdirlv` (`prod_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `props`
--

DROP TABLE IF EXISTS `props`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `props` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `bsn` varchar(255) DEFAULT NULL,
  `prop` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `requirement`
--

DROP TABLE IF EXISTS `requirement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `requirement` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `budget` varchar(255) NOT NULL,
  `cancel_time` datetime(6) DEFAULT NULL,
  `close_time` datetime(6) DEFAULT NULL,
  `contact` varchar(255) NOT NULL,
  `r_desc` varchar(255) NOT NULL,
  `r_field` varchar(255) NOT NULL,
  `finish_time` datetime(6) DEFAULT NULL,
  `is_homepage_display` int(11) DEFAULT NULL,
  `is_selected` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) NOT NULL,
  `project_loc` varchar(255) DEFAULT NULL,
  `display_seq` int(11) DEFAULT NULL,
  `r_title` varchar(255) NOT NULL,
  `verify_status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC
/*!50100 PARTITION BY KEY ()
(PARTITION p0 ENGINE = InnoDB,
 PARTITION p1 ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `schema_to_firm`
--

DROP TABLE IF EXISTS `schema_to_firm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_to_firm` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `ds_schema` varchar(255) DEFAULT NULL,
  `firm_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC
/*!50100 PARTITION BY KEY ()
(PARTITION p0 ENGINE = InnoDB,
 PARTITION p1 ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `service_order`
--

DROP TABLE IF EXISTS `service_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_order` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `user_type` varchar(255) NOT NULL,
  `app_scenarios` varchar(255) NOT NULL,
  `cancel_time` datetime(6) DEFAULT NULL,
  `close_time` datetime(6) DEFAULT NULL,
  `contact` varchar(255) NOT NULL,
  `emial` varchar(255) NOT NULL,
  `finish_time` datetime(6) DEFAULT NULL,
  `mobile` varchar(255) NOT NULL,
  `order_status` varchar(255) NOT NULL,
  `price` decimal(19,2) DEFAULT NULL,
  `prod_name` varchar(255) NOT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `user_id` varchar(36) NOT NULL,
  `platform` varchar(100) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC
/*!50100 PARTITION BY KEY ()
(PARTITION p0 ENGINE = InnoDB,
 PARTITION p1 ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `service_provider`
--

DROP TABLE IF EXISTS `service_provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_provider` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `hits` int(11) DEFAULT NULL,
  `is_homepage_display` int(11) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `location_code` varchar(255) DEFAULT NULL,
  `sp_logo_url` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `sp_name` varchar(255) NOT NULL,
  `realname_auth` varchar(255) DEFAULT NULL,
  `display_seq` int(11) DEFAULT NULL,
  `service_years` varchar(255) DEFAULT NULL,
  `term_size` varchar(255) DEFAULT NULL,
  `hornor` text,
  `prods_and_services` text,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC
/*!50100 PARTITION BY KEY ()
(PARTITION p0 ENGINE = InnoDB,
 PARTITION p1 ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sp_case`
--

DROP TABLE IF EXISTS `sp_case`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sp_case` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `ps_desc` text,
  `name` varchar(255) NOT NULL,
  `service_provider_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK5d59rawlycig1usno3ll3nloc` (`service_provider_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC
/*!50100 PARTITION BY KEY ()
(PARTITION p0 ENGINE = InnoDB,
 PARTITION p1 ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sp_category`
--

DROP TABLE IF EXISTS `sp_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sp_category` (
  `id` varchar(255) NOT NULL,
  `sp_code` varchar(255) DEFAULT NULL,
  `sp_level` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `parent_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FKpbgw3b1fmt7gwtmsfpvvg8fv3` (`parent_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC
/*!50100 PARTITION BY KEY ()
(PARTITION p0 ENGINE = InnoDB,
 PARTITION p1 ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sp_sign_up`
--

DROP TABLE IF EXISTS `sp_sign_up`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sp_sign_up` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `addr` varchar(255) NOT NULL,
  `annual_sales` varchar(255) NOT NULL,
  `apply_reason` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `industry_sector` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC
/*!50100 PARTITION BY KEY ()
(PARTITION p0 ENGINE = InnoDB,
 PARTITION p1 ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sp_solution`
--

DROP TABLE IF EXISTS `sp_solution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sp_solution` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `content` text,
  `name` varchar(255) NOT NULL,
  `overall_design` text,
  `profile` text,
  `video_name` varchar(255) DEFAULT NULL,
  `video_url` varchar(255) DEFAULT NULL,
  `service_provider_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK9p9n0qokjgdrpls2q4x0y7lyc` (`service_provider_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC
/*!50100 PARTITION BY KEY ()
(PARTITION p0 ENGINE = InnoDB,
 PARTITION p1 ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `spark_feed_variable`
--

DROP TABLE IF EXISTS `spark_feed_variable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spark_feed_variable` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `feed_id` varchar(255) DEFAULT NULL,
  `monitor_prop` varchar(255) DEFAULT NULL,
  `result_feed_id` varchar(255) DEFAULT NULL,
  `spark_var` varchar(255) DEFAULT NULL,
  `value` double DEFAULT NULL,
  `variable` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_dict`
--

DROP TABLE IF EXISTS `sys_dict`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_dict` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `d_name` varchar(255) DEFAULT NULL,
  `d_property` varchar(255) DEFAULT NULL,
  `d_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `template_factor_item`
--

DROP TABLE IF EXISTS `template_factor_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `template_factor_item` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `compute_value` varchar(255) DEFAULT NULL,
  `feed_value_type` varchar(255) DEFAULT NULL,
  `log_to_feed_name` varchar(255) DEFAULT NULL,
  `operator` varchar(255) DEFAULT NULL,
  `operator_type` varchar(255) DEFAULT NULL,
  `seq` int(11) NOT NULL,
  `template_id` varchar(255) DEFAULT NULL,
  `value` double DEFAULT NULL,
  `feed_id` varchar(36) DEFAULT NULL,
  `input_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKt0h5v70hvsi7w41qft92qwavf` (`feed_id`),
  KEY `FK8v4iknn8l34hbrc9632hb19b3` (`input_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tenant_user`
--

DROP TABLE IF EXISTS `tenant_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tenant_user` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `id_num` varchar(255) DEFAULT NULL,
  `id_type` tinyint(4) DEFAULT NULL,
  `is_forbidden` tinyint(4) DEFAULT NULL,
  `mobile` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `real_name` varchar(255) DEFAULT NULL,
  `real_name_auth_status` varchar(255) DEFAULT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `user_type` varchar(255) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_c94csro6tfn98rkm5wrni7ixd` (`mobile`),
  UNIQUE KEY `UK_bjpignp2g82jcx943wawebole` (`username`),
  UNIQUE KEY `UK_q2bk9kyamc1dfw46os7y1ipyn` (`email`),
  UNIQUE KEY `UK_okm8j388yejibgwe8ln3x22go` (`id_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tenant_user_auth_info`
--

DROP TABLE IF EXISTS `tenant_user_auth_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tenant_user_auth_info` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `account_bank` varchar(255) NOT NULL,
  `bank_account` varchar(255) NOT NULL,
  `bus_license_url` varchar(255) NOT NULL,
  `corporate_name` varchar(255) NOT NULL,
  `credit_code` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `reg_addr` varchar(255) NOT NULL,
  `tenant_user_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_ibt4nr1vncxcc3i7ee1wmuktu` (`bank_account`),
  UNIQUE KEY `UK_cpyc603c6ti9essrdr6i3fu8x` (`corporate_name`),
  UNIQUE KEY `UK_sr5yn16jlahsbkwtjs4qhuhah` (`credit_code`),
  UNIQUE KEY `UK_27g4rf444o7mnrg57ympxaiwu` (`email`),
  KEY `FKdiqv0115m61s0jwcsdovsp00y` (`tenant_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tenant_user_basic_info`
--

DROP TABLE IF EXISTS `tenant_user_basic_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tenant_user_basic_info` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `corporate_name` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `main_business` varchar(255) NOT NULL,
  `major_industry` varchar(255) NOT NULL,
  `province` varchar(255) NOT NULL,
  `telephone` varchar(255) NOT NULL,
  `tenant_user_id` varchar(36) NOT NULL,
  `upload_province` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKinn8rgkd5enfev25adf49jh4q` (`tenant_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topic`
--

DROP TABLE IF EXISTS `topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topic` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `topic_desc` varchar(255) DEFAULT NULL,
  `is_del` tinyint(4) NOT NULL,
  `sp_type` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `device_id` varchar(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK9qq4g0jubhblbac5pxp47dk30` (`device_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topic_pattern`
--

DROP TABLE IF EXISTS `topic_pattern`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topic_pattern` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `pattern_desc` varchar(255) DEFAULT NULL,
  `is_del` tinyint(4) NOT NULL,
  `sp_type` varchar(255) NOT NULL,
  `pattern_val` varchar(255) NOT NULL,
  `prod_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK9jp9mlppqpxsq7jcf5cxhqu5n` (`prod_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topic_template`
--

DROP TABLE IF EXISTS `topic_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topic_template` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `pattern_desc` varchar(255) DEFAULT NULL,
  `is_del` tinyint(4) NOT NULL,
  `sp_type` varchar(255) NOT NULL,
  `pattern_val` varchar(255) NOT NULL,
  `prod_template_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKj2tdab03570fkuvdprchw95l9` (`prod_template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topologies`
--

DROP TABLE IF EXISTS `topologies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topologies` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `energy` varchar(255) DEFAULT NULL,
  `is_default` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topology_meter_to_props`
--

DROP TABLE IF EXISTS `topology_meter_to_props`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topology_meter_to_props` (
  `prop_id` varchar(36) NOT NULL,
  `topology_meter_id` varchar(36) NOT NULL,
  PRIMARY KEY (`prop_id`,`topology_meter_id`),
  KEY `FK56m3f9eihrolrau4ols4c5gun` (`topology_meter_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topology_meters`
--

DROP TABLE IF EXISTS `topology_meters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topology_meters` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `sn` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `mainstay_id` varchar(36) DEFAULT NULL,
  `organization_id` varchar(36) DEFAULT NULL,
  `parent_id` varchar(36) DEFAULT NULL,
  `topology_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKfbhdi2gdwkhv24kbaa2mhhfuj` (`mainstay_id`),
  KEY `FK4isaee1u1dtb31pnk7nglyf61` (`organization_id`),
  KEY `FK73jpd4sn2tn0h3s4va9t6vj74` (`parent_id`),
  KEY `FKcqubq950f2gwyneivp8cd834w` (`topology_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `training_video`
--

DROP TABLE IF EXISTS `training_video`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `training_video` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `video_url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC
/*!50100 PARTITION BY KEY ()
(PARTITION p0 ENGINE = InnoDB,
 PARTITION p1 ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `variable_value`
--

DROP TABLE IF EXISTS `variable_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `variable_value` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `value` double DEFAULT NULL,
  `variable` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_6wib258e3s4n8uvs50nh5tx6q` (`variable`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Current Database: `iot_FgVDFEyGda`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `iot_FgVDFEyGda` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `iot_FgVDFEyGda`;

--
-- Table structure for table `DATABASECHANGELOG`
--

DROP TABLE IF EXISTS `DATABASECHANGELOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DATABASECHANGELOG` (
  `ID` varchar(255) NOT NULL,
  `AUTHOR` varchar(255) NOT NULL,
  `FILENAME` varchar(255) NOT NULL,
  `DATEEXECUTED` datetime NOT NULL,
  `ORDEREXECUTED` int(11) NOT NULL,
  `EXECTYPE` varchar(10) NOT NULL,
  `MD5SUM` varchar(35) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `COMMENTS` varchar(255) DEFAULT NULL,
  `TAG` varchar(255) DEFAULT NULL,
  `LIQUIBASE` varchar(20) DEFAULT NULL,
  `CONTEXTS` varchar(255) DEFAULT NULL,
  `LABELS` varchar(255) DEFAULT NULL,
  `DEPLOYMENT_ID` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `DATABASECHANGELOGLOCK`
--

DROP TABLE IF EXISTS `DATABASECHANGELOGLOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DATABASECHANGELOGLOCK` (
  `ID` int(11) NOT NULL,
  `LOCKED` bit(1) NOT NULL,
  `LOCKGRANTED` datetime DEFAULT NULL,
  `LOCKEDBY` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `DATABASECHANGELOG_BAK`
--

DROP TABLE IF EXISTS `DATABASECHANGELOG_BAK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DATABASECHANGELOG_BAK` (
  `ID` varchar(255) NOT NULL,
  `AUTHOR` varchar(255) NOT NULL,
  `FILENAME` varchar(255) NOT NULL,
  `DATEEXECUTED` datetime NOT NULL,
  `ORDEREXECUTED` int(11) NOT NULL,
  `EXECTYPE` varchar(10) NOT NULL,
  `MD5SUM` varchar(35) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `COMMENTS` varchar(255) DEFAULT NULL,
  `TAG` varchar(255) DEFAULT NULL,
  `LIQUIBASE` varchar(20) DEFAULT NULL,
  `CONTEXTS` varchar(255) DEFAULT NULL,
  `LABELS` varchar(255) DEFAULT NULL,
  `DEPLOYMENT_ID` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alarm_configs`
--

DROP TABLE IF EXISTS `alarm_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alarm_configs` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `energy` varchar(255) DEFAULT NULL,
  `mode` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alarm_logs`
--

DROP TABLE IF EXISTS `alarm_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alarm_logs` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `energy` varchar(255) DEFAULT NULL,
  `organization_id` varchar(255) DEFAULT NULL,
  `read_time` datetime DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `config_id` varchar(36) DEFAULT NULL,
  `range_id` varchar(36) DEFAULT NULL,
  `trigger_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FKopneaxso8d6hfgk0arfxcyeh` (`config_id`) USING BTREE,
  KEY `FKdamiupawy80200wnfhtj8f6qv` (`range_id`) USING BTREE,
  KEY `FK5e1b2xp48ly6j0papbl5jyqcs` (`trigger_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alarm_ranges`
--

DROP TABLE IF EXISTS `alarm_ranges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alarm_ranges` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `organization_id` varchar(255) DEFAULT NULL,
  `config_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK98o5v07ulm42cin4j37rgqvsp` (`config_id`) USING BTREE,
  CONSTRAINT `FK98o5v07ulm42cin4j37rgqvsp` FOREIGN KEY (`config_id`) REFERENCES `alarm_configs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alarm_triggers`
--

DROP TABLE IF EXISTS `alarm_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alarm_triggers` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `max_value` double(11,2) DEFAULT NULL,
  `min_value` double(11,2) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `config_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FKlphsjn6h6jphtxp2shtj9qjki` (`config_id`) USING BTREE,
  CONSTRAINT `FKlphsjn6h6jphtxp2shtj9qjki` FOREIGN KEY (`config_id`) REFERENCES `alarm_configs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `back_door`
--

DROP TABLE IF EXISTS `back_door`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `back_door` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `base_price`
--

DROP TABLE IF EXISTS `base_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `base_price` (
  `id` varchar(36) NOT NULL,
  `tax_amount` decimal(5,2) DEFAULT NULL COMMENT '税额',
  `unit_price_tax` decimal(10,2) DEFAULT NULL COMMENT '含税单价',
  `unit_price` decimal(7,2) DEFAULT NULL COMMENT '不含税单价',
  `energy_type` varchar(45) DEFAULT NULL COMMENT '能源类型　water　水　steam　蒸汽　　nitrogen　氮气 eletric 电',
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='峰平谷尖';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `budgets`
--

DROP TABLE IF EXISTS `budgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `budgets` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `air_value` varchar(255) DEFAULT NULL,
  `compressed_value` varchar(255) DEFAULT NULL,
  `electric_value` varchar(255) DEFAULT NULL,
  `heat_value` varchar(255) DEFAULT NULL,
  `organization_id` varchar(255) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `water_value` varchar(255) DEFAULT NULL,
  `budget_time` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='预算录入';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cfg_file_to_comm_file`
--

DROP TABLE IF EXISTS `cfg_file_to_comm_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cfg_file_to_comm_file` (
  `cfg_file_id` varchar(36) NOT NULL,
  `comm_file_id` varchar(36) NOT NULL,
  PRIMARY KEY (`cfg_file_id`,`comm_file_id`),
  KEY `FK3dhh4x57vhr49p0fw5xhocalu` (`comm_file_id`),
  CONSTRAINT `FK3dhh4x57vhr49p0fw5xhocalu` FOREIGN KEY (`comm_file_id`) REFERENCES `comm_file` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK6us1bxqbqp1s2ax95q4275b78` FOREIGN KEY (`cfg_file_id`) REFERENCES `config_file_list` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `com_info`
--

DROP TABLE IF EXISTS `com_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `com_info` (
  `name` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC
/*!50100 PARTITION BY KEY (`name`)
(PARTITION p0 ENGINE = InnoDB,
 PARTITION p1 ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `comm_file`
--

DROP TABLE IF EXISTS `comm_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comm_file` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `file_content` longblob NOT NULL,
  `file_content_type` varchar(255) DEFAULT NULL,
  `file_fullname` varchar(255) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_size` bigint(20) DEFAULT NULL,
  `file_status` int(11) DEFAULT NULL,
  `file_suffix` varchar(255) DEFAULT NULL,
  `file_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `conf_seg_file`
--

DROP TABLE IF EXISTS `conf_seg_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conf_seg_file` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `file_content` longblob NOT NULL,
  `seg_crc` varchar(255) DEFAULT NULL,
  `seg_seq` int(11) DEFAULT NULL,
  `seg_size` int(11) DEFAULT NULL,
  `type` int(2) DEFAULT NULL,
  `fir_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKsuk4xpsohu5mnskekvjek8cg0` (`fir_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `config_file_list`
--

DROP TABLE IF EXISTS `config_file_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config_file_list` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `config_ver` varchar(255) NOT NULL,
  `is_valid` int(11) DEFAULT NULL,
  `iot_device_id` varchar(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1xs7pkmbuiyxi788kc692n5hj` (`iot_device_id`),
  CONSTRAINT `FK1xs7pkmbuiyxi788kc692n5hj` FOREIGN KEY (`iot_device_id`) REFERENCES `iot_device` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `config_update_record`
--

DROP TABLE IF EXISTS `config_update_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config_update_record` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `new_ver` varchar(255) NOT NULL,
  `old_ver` varchar(255) DEFAULT NULL,
  `update_status` varchar(255) NOT NULL,
  `time_end` datetime(6) DEFAULT NULL,
  `time_start` datetime(6) NOT NULL,
  `iot_device_id` varchar(36) NOT NULL,
  `reason` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKjmvbafjradxdjdcm59rt06h7` (`iot_device_id`),
  CONSTRAINT `FKjmvbafjradxdjdcm59rt06h7` FOREIGN KEY (`iot_device_id`) REFERENCES `iot_device` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `config_update_record_item`
--

DROP TABLE IF EXISTS `config_update_record_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config_update_record_item` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `i_desc` varchar(255) DEFAULT NULL,
  `i_version` varchar(255) DEFAULT NULL,
  `i_step` varchar(255) DEFAULT NULL,
  `i_time` datetime(6) DEFAULT NULL,
  `record_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKbwwrr33oqionl38xwcnmibtkl` (`record_id`),
  CONSTRAINT `FKbwwrr33oqionl38xwcnmibtkl` FOREIGN KEY (`record_id`) REFERENCES `config_update_record` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `data_up_error`
--

DROP TABLE IF EXISTS `data_up_error`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_up_error` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `product_id` varchar(255) DEFAULT NULL,
  `sn` varchar(255) DEFAULT NULL,
  `sn_type` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `topic` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `device_alarm_log`
--

DROP TABLE IF EXISTS `device_alarm_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_alarm_log` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(8) DEFAULT NULL,
  `device_id` varchar(36) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `detail` varchar(500) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC
/*!50100 PARTITION BY KEY ()
(PARTITION p0 ENGINE = InnoDB,
 PARTITION p1 ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `device_virtual_feed`
--

DROP TABLE IF EXISTS `device_virtual_feed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_virtual_feed` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `result_feed_id` varchar(255) DEFAULT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `interval_value` int(11) DEFAULT NULL,
  `interval_unit_type` varchar(45) DEFAULT NULL,
  `monitor_prop` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dosage_day`
--

DROP TABLE IF EXISTS `dosage_day`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dosage_day` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `data_time` varchar(50) DEFAULT NULL,
  `end_time` varchar(50) DEFAULT NULL,
  `feed_id` varchar(36) DEFAULT NULL,
  `start_time` varchar(50) DEFAULT NULL,
  `statistic_value` double DEFAULT NULL,
  `step` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dosage_half`
--

DROP TABLE IF EXISTS `dosage_half`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dosage_half` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `data_time` varchar(50) DEFAULT NULL,
  `end_time` varchar(50) DEFAULT NULL,
  `feed_id` varchar(36) DEFAULT NULL,
  `start_time` varchar(50) DEFAULT NULL,
  `statistic_value` double DEFAULT NULL,
  `step` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dosage_hour`
--

DROP TABLE IF EXISTS `dosage_hour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dosage_hour` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `data_time` varchar(50) DEFAULT NULL,
  `end_time` varchar(50) DEFAULT NULL,
  `feed_id` varchar(36) DEFAULT NULL,
  `start_time` varchar(50) DEFAULT NULL,
  `statistic_value` double DEFAULT NULL,
  `step` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dosage_month`
--

DROP TABLE IF EXISTS `dosage_month`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dosage_month` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `data_time` varchar(50) DEFAULT NULL,
  `end_time` varchar(50) DEFAULT NULL,
  `feed_id` varchar(36) DEFAULT NULL,
  `start_time` varchar(50) DEFAULT NULL,
  `statistic_value` double DEFAULT NULL,
  `step` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dosage_phase`
--

DROP TABLE IF EXISTS `dosage_phase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dosage_phase` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `data_time` varchar(50) DEFAULT NULL,
  `data_value` double DEFAULT NULL,
  `feed_id` varchar(36) DEFAULT NULL,
  `prop` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `edge_alarm_log`
--

DROP TABLE IF EXISTS `edge_alarm_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge_alarm_log` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(8) DEFAULT NULL,
  `edge_device_id` varchar(36) DEFAULT NULL,
  `edge_code` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `detail` varchar(500) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC
/*!50100 PARTITION BY KEY ()
(PARTITION p0 ENGINE = InnoDB,
 PARTITION p1 ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `edge_device`
--

DROP TABLE IF EXISTS `edge_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge_device` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(8) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `agreement` varchar(255) DEFAULT NULL,
  `soft_version` varchar(255) DEFAULT NULL,
  `configuration` varchar(500) DEFAULT NULL,
  `last_time` datetime DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `edge_log`
--

DROP TABLE IF EXISTS `edge_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge_log` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `log_code` varchar(36) DEFAULT NULL,
  `edge_name` varchar(255) DEFAULT NULL,
  `edge_code` varchar(255) DEFAULT NULL,
  `log_time` datetime DEFAULT NULL,
  `log_detail` varchar(1000) DEFAULT NULL,
  `log_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `edge_to_dtu`
--

DROP TABLE IF EXISTS `edge_to_dtu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edge_to_dtu` (
  `edge_id` varchar(36) NOT NULL,
  `dtu_id` varchar(36) NOT NULL,
  PRIMARY KEY (`edge_id`,`dtu_id`),
  KEY `index_to_dtu` (`dtu_id`),
  CONSTRAINT `fk_to_dtu` FOREIGN KEY (`dtu_id`) REFERENCES `iot_device` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_to_edge` FOREIGN KEY (`edge_id`) REFERENCES `edge_device` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elec_value`
--

DROP TABLE IF EXISTS `elec_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elec_value` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `bsn` varchar(45) DEFAULT NULL,
  `data_time` bigint(15) DEFAULT NULL,
  `statistic_value` double DEFAULT NULL,
  `data_month` int(11) DEFAULT NULL,
  `data_year` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='峰平谷尖整理数据';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `electricity_rule`
--

DROP TABLE IF EXISTS `electricity_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `electricity_rule` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `rules` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy`
--

DROP TABLE IF EXISTS `energy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL COMMENT '最后修改时间',
  `statistics_time` varchar(45) DEFAULT NULL COMMENT '统计周期',
  `name` varchar(45) CHARACTER SET utf8 DEFAULT NULL COMMENT '报表名称',
  `state` tinyint(1) DEFAULT NULL COMMENT '状态',
  `user_name` varchar(30) CHARACTER SET utf8 DEFAULT NULL COMMENT '最后修改人',
  `energy` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '能源',
  `last_user_id` varchar(36) DEFAULT NULL COMMENT '最后修改用户名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='kpi列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_data`
--

DROP TABLE IF EXISTS `energy_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_data` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `energy_report_id` varchar(36) DEFAULT NULL COMMENT '能耗报表结构id',
  `reading_this_month` float(20,2) DEFAULT NULL COMMENT '本月读数',
  `last_month_reading` float(20,2) DEFAULT NULL COMMENT '上月读数',
  `actual_dosage` float(20,2) DEFAULT NULL COMMENT '实际用量',
  `total` float(20,2) DEFAULT NULL COMMENT '总量',
  `price` float(20,2) DEFAULT NULL COMMENT '价格',
  `tax` float(20,2) DEFAULT NULL COMMENT '税额',
  `tax_included_price` float(20,2) DEFAULT NULL COMMENT '含税价格',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='折标煤表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_report`
--

DROP TABLE IF EXISTS `energy_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_report` (
  `id` varchar(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL COMMENT '标题',
  `type` varchar(255) DEFAULT NULL COMMENT '节点类型',
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `structure_id` varchar(36) DEFAULT NULL COMMENT '结构id',
  `parent_structure_id` varchar(36) DEFAULT NULL COMMENT '结构父节点id',
  `energy_id` varchar(36) DEFAULT NULL COMMENT '主表列表i的id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='折标煤表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_report_logs`
--

DROP TABLE IF EXISTS `energy_report_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_report_logs` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `energy_id` varchar(36) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC
/*!50100 PARTITION BY KEY ()
(PARTITION p0 ENGINE = InnoDB,
 PARTITION p1 ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_total`
--

DROP TABLE IF EXISTS `energy_total`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_total` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `total_invoice` float(10,2) DEFAULT NULL COMMENT '发票总量',
  `invoice_amount` float(10,2) DEFAULT NULL COMMENT '发票金额',
  `energy_id` varchar(36) DEFAULT NULL COMMENT '主表列表i的id',
  `company_list` float(10,2) DEFAULT NULL COMMENT '公司总表',
  `sum_tables` float(10,2) DEFAULT NULL COMMENT '分表之和',
  `practical_total` float(10,2) DEFAULT NULL COMMENT '实用量',
  `price` float(10,2) DEFAULT NULL COMMENT '价格',
  `tax_amount` float(10,2) DEFAULT NULL,
  `tax_inclusive_price` float(10,2) DEFAULT NULL,
  `invoice_company` float(10,2) DEFAULT NULL,
  `sum_company` float(10,2) DEFAULT NULL,
  `sum_invoice` float(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='折标煤表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `environment_info`
--

DROP TABLE IF EXISTS `environment_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `environment_info` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `config_ok` int(11) DEFAULT NULL,
  `config_version` varchar(255) DEFAULT NULL,
  `data_format` varchar(255) DEFAULT NULL,
  `device_name` varchar(255) DEFAULT NULL,
  `device_secret` varchar(255) DEFAULT NULL,
  `firmware_ok` int(11) DEFAULT NULL,
  `firmware_version` varchar(255) NOT NULL,
  `mqtt_ip` varchar(255) DEFAULT NULL,
  `mqtt_port` varchar(255) DEFAULT NULL,
  `on_time` int(11) DEFAULT NULL,
  `product_key` varchar(255) DEFAULT NULL,
  `product_secret` varchar(255) DEFAULT NULL,
  `send_interval` int(11) DEFAULT NULL,
  `sn` varchar(255) DEFAULT NULL,
  `sn_activate_flag` int(11) DEFAULT NULL,
  `sn_config_flag` int(11) DEFAULT NULL,
  `type_ok` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `expression`
--

DROP TABLE IF EXISTS `expression`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expression` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `expression` varchar(255) DEFAULT NULL,
  `input_id` varchar(255) DEFAULT NULL,
  `log_to_feed_id` varchar(255) DEFAULT NULL,
  `seq` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `factor_item`
--

DROP TABLE IF EXISTS `factor_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factor_item` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `compute_value` varchar(255) DEFAULT NULL,
  `operator` varchar(255) DEFAULT NULL,
  `operator_type` varchar(255) DEFAULT NULL,
  `seq` int(11) NOT NULL,
  `value` double DEFAULT NULL,
  `factor_type_id` varchar(36) DEFAULT NULL,
  `feed_id` varchar(36) DEFAULT NULL,
  `input_id` varchar(36) DEFAULT NULL,
  `log_to_feed_id` varchar(36) DEFAULT NULL,
  `compute_input_id` varchar(36) DEFAULT NULL,
  `compute_ori_feed_id` varchar(36) DEFAULT NULL,
  `log_to_feed_type` varchar(255) DEFAULT NULL,
  `log_to_feed_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK3kryw6umw6u7ojl5y5fqmjxye` (`compute_input_id`) USING BTREE,
  KEY `FK9hyi8t0nkricis6kkmuh4pfhu` (`factor_type_id`) USING BTREE,
  KEY `FKrddfdi06i7t8nmdxe3eocq3ih` (`feed_id`) USING BTREE,
  KEY `FKg7t6egoi32k258jq87u5q93bu` (`input_id`) USING BTREE,
  KEY `FK3wl11tgtfrsm1cp5bx9ppvp21` (`log_to_feed_id`) USING BTREE,
  CONSTRAINT `factor_item_ibfk_1` FOREIGN KEY (`compute_input_id`) REFERENCES `input` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `factor_item_ibfk_2` FOREIGN KEY (`log_to_feed_id`) REFERENCES `feed` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `factor_item_ibfk_3` FOREIGN KEY (`factor_type_id`) REFERENCES `factor_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `factor_item_ibfk_4` FOREIGN KEY (`input_id`) REFERENCES `input` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `factor_item_ibfk_5` FOREIGN KEY (`feed_id`) REFERENCES `feed` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `factor_type`
--

DROP TABLE IF EXISTS `factor_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factor_type` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `factor_code` varchar(255) DEFAULT NULL,
  `factor_desc` varchar(255) DEFAULT NULL,
  `feed_id` varchar(255) DEFAULT NULL,
  `feed_name` varchar(255) DEFAULT NULL,
  `feed_unit` varchar(255) DEFAULT NULL,
  `factor_name` varchar(255) DEFAULT NULL,
  `factor_title` varchar(255) DEFAULT NULL,
  `item_value` decimal(19,2) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feed`
--

DROP TABLE IF EXISTS `feed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `feed_num` varchar(255) DEFAULT NULL,
  `interval_unit_type` varchar(255) DEFAULT NULL,
  `interval_value` double DEFAULT NULL,
  `last_value` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `unit_id` varchar(255) DEFAULT NULL,
  `update_time` datetime(6) DEFAULT NULL,
  `value_time` datetime(6) DEFAULT NULL,
  `is_default` tinyint(4) DEFAULT NULL,
  `input_id` varchar(36) DEFAULT NULL,
  `inst_id` varchar(255) DEFAULT NULL,
  `feed_type` varchar(45) DEFAULT NULL,
  `formula` varchar(255) DEFAULT NULL,
  `monitory_prop_code` varchar(255) DEFAULT NULL,
  `num` int(11) NOT NULL,
  `feed_log_value_type` varchar(255) DEFAULT NULL,
  `feed_value_type` varchar(255) DEFAULT NULL,
  `feed_id` varchar(255) DEFAULT NULL,
  `is_auto` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FKimcpat0ihf1mbs5r983pmsrd4` (`input_id`) USING BTREE,
  CONSTRAINT `FKimcpat0ihf1mbs5r983pmsrd4` FOREIGN KEY (`input_id`) REFERENCES `input` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feed_alarm_log`
--

DROP TABLE IF EXISTS `feed_alarm_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed_alarm_log` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `alarm_condition` varchar(255) DEFAULT NULL,
  `alarm_id` varchar(36) DEFAULT NULL,
  `alarm_level` varchar(255) DEFAULT NULL,
  `alarm_platform` varchar(255) DEFAULT NULL,
  `alarm_time` datetime(6) DEFAULT NULL,
  `alarm_type` varchar(255) DEFAULT NULL,
  `alarm_value` varchar(255) DEFAULT NULL,
  `critical` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `num` int(11) DEFAULT NULL,
  `pool` int(11) DEFAULT NULL,
  `record_id` varchar(36) DEFAULT NULL,
  `threshold` double DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `device_id` varchar(36) DEFAULT NULL,
  `device_name` varchar(255) DEFAULT NULL,
  `feed_id` varchar(36) DEFAULT NULL,
  `feed_name` varchar(255) DEFAULT NULL,
  `feed_prop` varchar(255) DEFAULT NULL,
  `instrument_id` varchar(255) DEFAULT NULL,
  `product_id` varchar(36) DEFAULT NULL,
  `product_name` varchar(100) DEFAULT NULL,
  `unit` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feed_alarm_record`
--

DROP TABLE IF EXISTS `feed_alarm_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed_alarm_record` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `alarm_id` varchar(255) DEFAULT NULL,
  `end_time` datetime(6) DEFAULT NULL,
  `modifier` varchar(255) DEFAULT NULL,
  `record_type` varchar(255) DEFAULT NULL,
  `recover_type` varchar(255) DEFAULT NULL,
  `start_time` datetime(6) DEFAULT NULL,
  `state` bit(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feed_alarm_record_condition`
--

DROP TABLE IF EXISTS `feed_alarm_record_condition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed_alarm_record_condition` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `alarm_key` varchar(255) DEFAULT NULL,
  `alarm_value` double DEFAULT NULL,
  `record_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feed_compute`
--

DROP TABLE IF EXISTS `feed_compute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed_compute` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `feed_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feed_expression_variable`
--

DROP TABLE IF EXISTS `feed_expression_variable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed_expression_variable` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `expression` varchar(255) DEFAULT NULL,
  `feed_id` varchar(255) DEFAULT NULL,
  `place` varchar(255) DEFAULT NULL,
  `result_feed_id` varchar(255) DEFAULT NULL,
  `variable` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feed_formula_template`
--

DROP TABLE IF EXISTS `feed_formula_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed_formula_template` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `feed_name` varchar(255) DEFAULT NULL,
  `feed_value_type` varchar(255) DEFAULT NULL,
  `interval_unit_type` varchar(255) DEFAULT NULL,
  `interval_value` int(11) DEFAULT NULL,
  `template_id` varchar(255) DEFAULT NULL,
  `unit_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feed_value`
--

DROP TABLE IF EXISTS `feed_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed_value` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `feed_id` varchar(255) DEFAULT NULL,
  `value` double DEFAULT NULL,
  `value_time` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feed_value_daily`
--

DROP TABLE IF EXISTS `feed_value_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed_value_daily` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `feed_id` varchar(255) DEFAULT NULL,
  `value` double DEFAULT NULL,
  `value_time` datetime(6) DEFAULT NULL,
  `value_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feed_value_hourly`
--

DROP TABLE IF EXISTS `feed_value_hourly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed_value_hourly` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `feed_id` varchar(255) DEFAULT NULL,
  `value` double DEFAULT NULL,
  `value_time` datetime(6) DEFAULT NULL,
  `value_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `firmware_update_record`
--

DROP TABLE IF EXISTS `firmware_update_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `firmware_update_record` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `end_time` datetime(6) DEFAULT NULL,
  `new_ver` varchar(255) DEFAULT NULL,
  `old_ver` varchar(255) DEFAULT NULL,
  `rec_reason` varchar(255) DEFAULT NULL,
  `start_time` datetime(6) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `device_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK5upa7g40i0474duu9kvsoou4t` (`device_id`),
  CONSTRAINT `FK5upa7g40i0474duu9kvsoou4t` FOREIGN KEY (`device_id`) REFERENCES `iot_device` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `firmware_update_record_item`
--

DROP TABLE IF EXISTS `firmware_update_record_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `firmware_update_record_item` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `i_desc` varchar(255) DEFAULT NULL,
  `i_version` varchar(255) DEFAULT NULL,
  `i_step` varchar(255) DEFAULT NULL,
  `i_time` datetime(6) DEFAULT NULL,
  `record_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKi4vmt6p65s5qyynyulem0gjqa` (`record_id`),
  CONSTRAINT `FKi4vmt6p65s5qyynyulem0gjqa` FOREIGN KEY (`record_id`) REFERENCES `firmware_update_record` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `formula_template`
--

DROP TABLE IF EXISTS `formula_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `formula_template` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `expression` varchar(255) DEFAULT NULL,
  `factor_item_list` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `product_id` varchar(255) DEFAULT NULL,
  `prop` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `graph`
--

DROP TABLE IF EXISTS `graph`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `graph` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `end_time` datetime(6) DEFAULT NULL,
  `feed_id` varchar(255) DEFAULT NULL,
  `fill_color` varchar(255) DEFAULT NULL,
  `graph_name` varchar(255) DEFAULT NULL,
  `graph_type` varchar(255) DEFAULT NULL,
  `inst_id` varchar(255) DEFAULT NULL,
  `iot_device_id` varchar(255) DEFAULT NULL,
  `iot_product_id` varchar(255) DEFAULT NULL,
  `is_fill` bit(1) DEFAULT NULL,
  `start_time` datetime(6) DEFAULT NULL,
  `time_type` varchar(255) DEFAULT NULL,
  `y_max_val` varchar(255) DEFAULT NULL,
  `y_min_val` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `input`
--

DROP TABLE IF EXISTS `input`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `input` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `expression` varchar(255) DEFAULT NULL,
  `prop` varchar(255) DEFAULT NULL,
  `prop_name` varchar(255) DEFAULT NULL,
  `property_code` varchar(255) DEFAULT NULL,
  `property_name` varchar(255) DEFAULT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `unit_code` varchar(255) DEFAULT NULL,
  `unit_id` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `value_time` datetime(6) DEFAULT NULL,
  `topic_id` varchar(36) DEFAULT NULL,
  `inst_addr` varchar(255) DEFAULT NULL,
  `inst_type` varchar(255) DEFAULT NULL,
  `inst_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK3ve3064u5p8ut0bamxjxgha1r` (`topic_id`) USING BTREE,
  CONSTRAINT `FK3ve3064u5p8ut0bamxjxgha1r` FOREIGN KEY (`topic_id`) REFERENCES `topic` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `input_formula_template`
--

DROP TABLE IF EXISTS `input_formula_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `input_formula_template` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `input_id` varchar(255) DEFAULT NULL,
  `template_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `instrument`
--

DROP TABLE IF EXISTS `instrument`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instrument` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `addr` varchar(255) DEFAULT NULL,
  `device_id` varchar(255) NOT NULL,
  `sn_type` varchar(255) DEFAULT NULL,
  `topic_id` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `iot_bsn`
--

DROP TABLE IF EXISTS `iot_bsn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iot_bsn` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `bsn` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `valid_date` datetime(6) NOT NULL,
  `invalid_date` datetime(6) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `inst_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `iot_device`
--

DROP TABLE IF EXISTS `iot_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iot_device` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `active_status` varchar(255) DEFAULT NULL,
  `active_time` datetime(6) DEFAULT NULL,
  `adjust_status` varchar(255) DEFAULT NULL,
  `config_file_ver` varchar(255) DEFAULT NULL,
  `firmware_update_status` varchar(255) DEFAULT NULL,
  `firmware_ver` varchar(255) DEFAULT NULL,
  `ip_addr` varchar(255) DEFAULT NULL,
  `is_del` tinyint(4) NOT NULL,
  `keep_online_or_offline_time` datetime(6) DEFAULT NULL,
  `last_online_time` datetime(6) DEFAULT NULL,
  `dev_name` varchar(255) NOT NULL,
  `note_name` varchar(255) DEFAULT NULL,
  `secret` varchar(255) DEFAULT NULL,
  `dev_seri_no` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `status_update_time` datetime(6) DEFAULT NULL,
  `iot_product_id` varchar(36) NOT NULL,
  `domain` varchar(255) DEFAULT NULL,
  `mqtt_server` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK48ophw25a6jkn33n5n7rdm0xi` (`iot_product_id`),
  CONSTRAINT `FK48ophw25a6jkn33n5n7rdm0xi` FOREIGN KEY (`iot_product_id`) REFERENCES `iot_product` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `iot_device_shadow`
--

DROP TABLE IF EXISTS `iot_device_shadow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iot_device_shadow` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `shadow` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `update_time` datetime(6) DEFAULT NULL,
  `device_id` varchar(36) DEFAULT NULL,
  `send_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKr4iqc0nrymmshbtdeeaepohun` (`device_id`),
  CONSTRAINT `FKr4iqc0nrymmshbtdeeaepohun` FOREIGN KEY (`device_id`) REFERENCES `iot_device` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `iot_product`
--

DROP TABLE IF EXISTS `iot_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iot_product` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `prod_desc` varchar(255) DEFAULT NULL,
  `is_del` tinyint(4) NOT NULL,
  `prod_key` varchar(255) DEFAULT NULL,
  `prod_name` varchar(255) NOT NULL,
  `node_type` varchar(255) DEFAULT NULL,
  `prod_category_id` varchar(255) NOT NULL,
  `prod_secret` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi`
--

DROP TABLE IF EXISTS `kpi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi` (
  `id` varchar(36) NOT NULL,
  `statistics_time` varchar(45) DEFAULT NULL COMMENT '统计周期',
  `title` varchar(45) DEFAULT NULL COMMENT 'kpi报表名',
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='kpi列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_detail`
--

DROP TABLE IF EXISTS `kpi_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_detail` (
  `id` varchar(36) NOT NULL,
  `tm_id` varchar(45) DEFAULT '' COMMENT '节点唯一标识',
  `workshop` varchar(45) DEFAULT '' COMMENT '车间',
  `department` varchar(45) DEFAULT '' COMMENT '部门名',
  `production` varchar(45) DEFAULT '' COMMENT '产品',
  `production_number` int(11) DEFAULT NULL COMMENT '产品数量',
  `unit` varchar(5) DEFAULT '' COMMENT '单位',
  `eletric_usage` varchar(45) DEFAULT '' COMMENT '电量',
  `water_usage` varchar(45) DEFAULT '' COMMENT '水量',
  `steam_usage` varchar(45) DEFAULT '' COMMENT '蒸汽用量',
  `nitrogen_usage` varchar(45) DEFAULT '' COMMENT '氮气用量',
  `compressed_air` varchar(45) DEFAULT '' COMMENT '压缩空气用量',
  `eletric_sc` varchar(45) DEFAULT '' COMMENT '电折标煤',
  `water_sc` varchar(45) DEFAULT '' COMMENT '水折标煤',
  `steam_sc` varchar(45) DEFAULT '' COMMENT '气折标煤',
  `nitrogen_sc` varchar(45) DEFAULT '' COMMENT '氮气折标煤',
  `compressed_air_sc` varchar(45) DEFAULT '' COMMENT '压缩空气折标煤气',
  `total` varchar(45) DEFAULT '' COMMENT '总计',
  `unit_usage` varchar(45) DEFAULT '' COMMENT '产品单耗',
  `kpi_id` varchar(45) DEFAULT '' COMMENT 'kpi表外键',
  `modify_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `department_id` varchar(36) DEFAULT '' COMMENT '部门唯一标识',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='kpi详情表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_sum`
--

DROP TABLE IF EXISTS `kpi_sum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_sum` (
  `id` varchar(36) NOT NULL,
  `eletric_usage` varchar(45) DEFAULT '' COMMENT '电量',
  `water_usage` varchar(45) DEFAULT '' COMMENT '水量',
  `steam_usage` varchar(45) DEFAULT '' COMMENT '蒸汽用量',
  `nitrogen_usage` varchar(45) DEFAULT '' COMMENT '氮气用量',
  `compressed_air` varchar(45) DEFAULT '' COMMENT '压缩空气用量',
  `eletric_sc` varchar(45) DEFAULT '' COMMENT '电折标煤',
  `water_sc` varchar(45) DEFAULT '' COMMENT '水折标煤',
  `steam_sc` varchar(45) DEFAULT '' COMMENT '气折标煤',
  `nitrogen_sc` varchar(45) DEFAULT '' COMMENT '氮气折标煤',
  `compressed_air_sc` varchar(45) DEFAULT '' COMMENT '压缩空气折标煤气',
  `total` varchar(45) DEFAULT '' COMMENT '总计',
  `kpi_id` varchar(45) DEFAULT '' COMMENT 'kpi表外键',
  `version` int(11) DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='kpi汇总表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mainstays`
--

DROP TABLE IF EXISTS `mainstays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mainstays` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `parent_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FKey362h3nwshbvtjqr76wcky2f` (`parent_id`) USING BTREE,
  CONSTRAINT `FKey362h3nwshbvtjqr76wcky2f` FOREIGN KEY (`parent_id`) REFERENCES `mainstays` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organizations`
--

DROP TABLE IF EXISTS `organizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organizations` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `mainstay_id` varchar(36) DEFAULT NULL,
  `parent_id` varchar(36) DEFAULT NULL,
  `produce` tinyint(1) DEFAULT '1' COMMENT '是否为生产车间0否1是',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK6yevr6xuwsittmrmb5ptjqxfx` (`mainstay_id`) USING BTREE,
  KEY `FKgsay2unfbsax6k1ulw0k557o7` (`parent_id`) USING BTREE,
  CONSTRAINT `FK6yevr6xuwsittmrmb5ptjqxfx` FOREIGN KEY (`mainstay_id`) REFERENCES `mainstays` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ota_firmware_info`
--

DROP TABLE IF EXISTS `ota_firmware_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ota_firmware_info` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `fir_alg` varchar(255) NOT NULL,
  `fir_check_result` varchar(255) DEFAULT NULL,
  `fir_checksum` varchar(255) NOT NULL,
  `fir_cust_version` varchar(255) NOT NULL,
  `fir_desc` varchar(100) DEFAULT NULL,
  `fir_en` varchar(255) NOT NULL,
  `fir_file_id` varchar(255) NOT NULL,
  `fir_seq_cnt` int(11) DEFAULT NULL,
  `prod_id` varchar(36) DEFAULT NULL,
  `fir_name` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKyruj7vawy1imc76rgruqdkaj` (`prod_id`),
  CONSTRAINT `FKyruj7vawy1imc76rgruqdkaj` FOREIGN KEY (`prod_id`) REFERENCES `iot_product` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ota_seg_file`
--

DROP TABLE IF EXISTS `ota_seg_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ota_seg_file` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `file_content` longblob NOT NULL,
  `seg_crc` varchar(255) DEFAULT NULL,
  `seg_crc_len` int(11) DEFAULT NULL,
  `seg_seq` int(11) DEFAULT NULL,
  `seg_size` int(11) DEFAULT NULL,
  `fir_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKsuk4xpsohu5mnskekvjek8cg0` (`fir_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pinggu`
--

DROP TABLE IF EXISTS `pinggu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pinggu` (
  `id` varchar(36) NOT NULL,
  `electricity_charge_type` varchar(45) DEFAULT NULL COMMENT '电价类型',
  `month` int(2) DEFAULT NULL COMMENT '月份',
  `price` decimal(5,2) DEFAULT NULL COMMENT '价格',
  `area` varchar(45) DEFAULT NULL COMMENT '地区',
  `create_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='峰平谷尖';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pinggu_recount`
--

DROP TABLE IF EXISTS `pinggu_recount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pinggu_recount` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `rerun_date` varchar(10) DEFAULT NULL COMMENT '需要重新计算的日期',
  `exec_time` datetime DEFAULT NULL COMMENT '重新计算计划开始的时间（精确到分钟，秒用00 补充）',
  `bsn` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='折标煤表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_ac001`
--

DROP TABLE IF EXISTS `preparation_2019_10_ac001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_ac001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_ac002`
--

DROP TABLE IF EXISTS `preparation_2019_10_ac002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_ac002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_ac003`
--

DROP TABLE IF EXISTS `preparation_2019_10_ac003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_ac003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_ac004`
--

DROP TABLE IF EXISTS `preparation_2019_10_ac004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_ac004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_ac005`
--

DROP TABLE IF EXISTS `preparation_2019_10_ac005`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_ac005` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_ac006`
--

DROP TABLE IF EXISTS `preparation_2019_10_ac006`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_ac006` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_ac007`
--

DROP TABLE IF EXISTS `preparation_2019_10_ac007`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_ac007` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_ac008`
--

DROP TABLE IF EXISTS `preparation_2019_10_ac008`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_ac008` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_ac009`
--

DROP TABLE IF EXISTS `preparation_2019_10_ac009`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_ac009` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_ac010`
--

DROP TABLE IF EXISTS `preparation_2019_10_ac010`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_ac010` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_ac011`
--

DROP TABLE IF EXISTS `preparation_2019_10_ac011`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_ac011` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_ac012`
--

DROP TABLE IF EXISTS `preparation_2019_10_ac012`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_ac012` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_ac013`
--

DROP TABLE IF EXISTS `preparation_2019_10_ac013`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_ac013` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_ca001`
--

DROP TABLE IF EXISTS `preparation_2019_10_ca001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_ca001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_ca002`
--

DROP TABLE IF EXISTS `preparation_2019_10_ca002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_ca002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_ca003`
--

DROP TABLE IF EXISTS `preparation_2019_10_ca003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_ca003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_ca004`
--

DROP TABLE IF EXISTS `preparation_2019_10_ca004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_ca004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_cd001`
--

DROP TABLE IF EXISTS `preparation_2019_10_cd001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_cd001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_cd002`
--

DROP TABLE IF EXISTS `preparation_2019_10_cd002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_cd002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_cd003`
--

DROP TABLE IF EXISTS `preparation_2019_10_cd003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_cd003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_cd004`
--

DROP TABLE IF EXISTS `preparation_2019_10_cd004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_cd004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_cl001`
--

DROP TABLE IF EXISTS `preparation_2019_10_cl001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_cl001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_el001`
--

DROP TABLE IF EXISTS `preparation_2019_10_el001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_el001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_el002`
--

DROP TABLE IF EXISTS `preparation_2019_10_el002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_el002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_el003`
--

DROP TABLE IF EXISTS `preparation_2019_10_el003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_el003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_el004`
--

DROP TABLE IF EXISTS `preparation_2019_10_el004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_el004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_el005`
--

DROP TABLE IF EXISTS `preparation_2019_10_el005`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_el005` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_el006`
--

DROP TABLE IF EXISTS `preparation_2019_10_el006`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_el006` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_el007`
--

DROP TABLE IF EXISTS `preparation_2019_10_el007`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_el007` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_el008`
--

DROP TABLE IF EXISTS `preparation_2019_10_el008`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_el008` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_el009`
--

DROP TABLE IF EXISTS `preparation_2019_10_el009`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_el009` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_el010`
--

DROP TABLE IF EXISTS `preparation_2019_10_el010`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_el010` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_el011`
--

DROP TABLE IF EXISTS `preparation_2019_10_el011`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_el011` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_el012`
--

DROP TABLE IF EXISTS `preparation_2019_10_el012`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_el012` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_el013`
--

DROP TABLE IF EXISTS `preparation_2019_10_el013`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_el013` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_el014`
--

DROP TABLE IF EXISTS `preparation_2019_10_el014`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_el014` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_el015`
--

DROP TABLE IF EXISTS `preparation_2019_10_el015`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_el015` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_el016`
--

DROP TABLE IF EXISTS `preparation_2019_10_el016`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_el016` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_el017`
--

DROP TABLE IF EXISTS `preparation_2019_10_el017`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_el017` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_el018`
--

DROP TABLE IF EXISTS `preparation_2019_10_el018`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_el018` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_el019`
--

DROP TABLE IF EXISTS `preparation_2019_10_el019`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_el019` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_el020`
--

DROP TABLE IF EXISTS `preparation_2019_10_el020`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_el020` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_el021`
--

DROP TABLE IF EXISTS `preparation_2019_10_el021`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_el021` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_el022`
--

DROP TABLE IF EXISTS `preparation_2019_10_el022`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_el022` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_el023`
--

DROP TABLE IF EXISTS `preparation_2019_10_el023`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_el023` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_el024`
--

DROP TABLE IF EXISTS `preparation_2019_10_el024`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_el024` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_ga001`
--

DROP TABLE IF EXISTS `preparation_2019_10_ga001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_ga001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_ga002`
--

DROP TABLE IF EXISTS `preparation_2019_10_ga002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_ga002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_ga003`
--

DROP TABLE IF EXISTS `preparation_2019_10_ga003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_ga003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_ga004`
--

DROP TABLE IF EXISTS `preparation_2019_10_ga004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_ga004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_nt001`
--

DROP TABLE IF EXISTS `preparation_2019_10_nt001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_nt001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_nt002`
--

DROP TABLE IF EXISTS `preparation_2019_10_nt002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_nt002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_nt003`
--

DROP TABLE IF EXISTS `preparation_2019_10_nt003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_nt003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_nt004`
--

DROP TABLE IF EXISTS `preparation_2019_10_nt004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_nt004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_ox001`
--

DROP TABLE IF EXISTS `preparation_2019_10_ox001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_ox001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_ox002`
--

DROP TABLE IF EXISTS `preparation_2019_10_ox002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_ox002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_ox003`
--

DROP TABLE IF EXISTS `preparation_2019_10_ox003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_ox003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_ox004`
--

DROP TABLE IF EXISTS `preparation_2019_10_ox004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_ox004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_st001`
--

DROP TABLE IF EXISTS `preparation_2019_10_st001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_st001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_st002`
--

DROP TABLE IF EXISTS `preparation_2019_10_st002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_st002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_st003`
--

DROP TABLE IF EXISTS `preparation_2019_10_st003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_st003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_st004`
--

DROP TABLE IF EXISTS `preparation_2019_10_st004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_st004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_wa001`
--

DROP TABLE IF EXISTS `preparation_2019_10_wa001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_wa001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_wa002`
--

DROP TABLE IF EXISTS `preparation_2019_10_wa002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_wa002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_wa003`
--

DROP TABLE IF EXISTS `preparation_2019_10_wa003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_wa003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_10_wa004`
--

DROP TABLE IF EXISTS `preparation_2019_10_wa004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_10_wa004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_ac001`
--

DROP TABLE IF EXISTS `preparation_2019_11_ac001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_ac001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_ac002`
--

DROP TABLE IF EXISTS `preparation_2019_11_ac002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_ac002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_ac003`
--

DROP TABLE IF EXISTS `preparation_2019_11_ac003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_ac003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_ac004`
--

DROP TABLE IF EXISTS `preparation_2019_11_ac004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_ac004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_ac005`
--

DROP TABLE IF EXISTS `preparation_2019_11_ac005`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_ac005` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_ac006`
--

DROP TABLE IF EXISTS `preparation_2019_11_ac006`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_ac006` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_ac007`
--

DROP TABLE IF EXISTS `preparation_2019_11_ac007`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_ac007` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_ac008`
--

DROP TABLE IF EXISTS `preparation_2019_11_ac008`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_ac008` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_ac009`
--

DROP TABLE IF EXISTS `preparation_2019_11_ac009`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_ac009` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_ac010`
--

DROP TABLE IF EXISTS `preparation_2019_11_ac010`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_ac010` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_ac011`
--

DROP TABLE IF EXISTS `preparation_2019_11_ac011`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_ac011` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_ac012`
--

DROP TABLE IF EXISTS `preparation_2019_11_ac012`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_ac012` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_ac013`
--

DROP TABLE IF EXISTS `preparation_2019_11_ac013`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_ac013` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_ca001`
--

DROP TABLE IF EXISTS `preparation_2019_11_ca001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_ca001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_ca002`
--

DROP TABLE IF EXISTS `preparation_2019_11_ca002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_ca002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_ca003`
--

DROP TABLE IF EXISTS `preparation_2019_11_ca003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_ca003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_ca004`
--

DROP TABLE IF EXISTS `preparation_2019_11_ca004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_ca004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_cd001`
--

DROP TABLE IF EXISTS `preparation_2019_11_cd001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_cd001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_cd002`
--

DROP TABLE IF EXISTS `preparation_2019_11_cd002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_cd002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_cd003`
--

DROP TABLE IF EXISTS `preparation_2019_11_cd003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_cd003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_cd004`
--

DROP TABLE IF EXISTS `preparation_2019_11_cd004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_cd004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_cl001`
--

DROP TABLE IF EXISTS `preparation_2019_11_cl001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_cl001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_el001`
--

DROP TABLE IF EXISTS `preparation_2019_11_el001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_el001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_el002`
--

DROP TABLE IF EXISTS `preparation_2019_11_el002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_el002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_el003`
--

DROP TABLE IF EXISTS `preparation_2019_11_el003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_el003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_el004`
--

DROP TABLE IF EXISTS `preparation_2019_11_el004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_el004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_el005`
--

DROP TABLE IF EXISTS `preparation_2019_11_el005`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_el005` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_el006`
--

DROP TABLE IF EXISTS `preparation_2019_11_el006`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_el006` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_el007`
--

DROP TABLE IF EXISTS `preparation_2019_11_el007`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_el007` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_el008`
--

DROP TABLE IF EXISTS `preparation_2019_11_el008`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_el008` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_el009`
--

DROP TABLE IF EXISTS `preparation_2019_11_el009`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_el009` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_el010`
--

DROP TABLE IF EXISTS `preparation_2019_11_el010`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_el010` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_el011`
--

DROP TABLE IF EXISTS `preparation_2019_11_el011`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_el011` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_el012`
--

DROP TABLE IF EXISTS `preparation_2019_11_el012`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_el012` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_el013`
--

DROP TABLE IF EXISTS `preparation_2019_11_el013`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_el013` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_el014`
--

DROP TABLE IF EXISTS `preparation_2019_11_el014`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_el014` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_el015`
--

DROP TABLE IF EXISTS `preparation_2019_11_el015`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_el015` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_el016`
--

DROP TABLE IF EXISTS `preparation_2019_11_el016`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_el016` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_el017`
--

DROP TABLE IF EXISTS `preparation_2019_11_el017`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_el017` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_el018`
--

DROP TABLE IF EXISTS `preparation_2019_11_el018`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_el018` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_el019`
--

DROP TABLE IF EXISTS `preparation_2019_11_el019`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_el019` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_el020`
--

DROP TABLE IF EXISTS `preparation_2019_11_el020`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_el020` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_el021`
--

DROP TABLE IF EXISTS `preparation_2019_11_el021`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_el021` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_el022`
--

DROP TABLE IF EXISTS `preparation_2019_11_el022`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_el022` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_el023`
--

DROP TABLE IF EXISTS `preparation_2019_11_el023`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_el023` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_el024`
--

DROP TABLE IF EXISTS `preparation_2019_11_el024`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_el024` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_ga001`
--

DROP TABLE IF EXISTS `preparation_2019_11_ga001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_ga001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_ga002`
--

DROP TABLE IF EXISTS `preparation_2019_11_ga002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_ga002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_ga003`
--

DROP TABLE IF EXISTS `preparation_2019_11_ga003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_ga003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_ga004`
--

DROP TABLE IF EXISTS `preparation_2019_11_ga004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_ga004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_nt001`
--

DROP TABLE IF EXISTS `preparation_2019_11_nt001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_nt001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_nt002`
--

DROP TABLE IF EXISTS `preparation_2019_11_nt002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_nt002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_nt003`
--

DROP TABLE IF EXISTS `preparation_2019_11_nt003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_nt003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_nt004`
--

DROP TABLE IF EXISTS `preparation_2019_11_nt004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_nt004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_ox001`
--

DROP TABLE IF EXISTS `preparation_2019_11_ox001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_ox001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_ox002`
--

DROP TABLE IF EXISTS `preparation_2019_11_ox002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_ox002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_ox003`
--

DROP TABLE IF EXISTS `preparation_2019_11_ox003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_ox003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_ox004`
--

DROP TABLE IF EXISTS `preparation_2019_11_ox004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_ox004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_st001`
--

DROP TABLE IF EXISTS `preparation_2019_11_st001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_st001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_st002`
--

DROP TABLE IF EXISTS `preparation_2019_11_st002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_st002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_st003`
--

DROP TABLE IF EXISTS `preparation_2019_11_st003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_st003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_st004`
--

DROP TABLE IF EXISTS `preparation_2019_11_st004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_st004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_wa001`
--

DROP TABLE IF EXISTS `preparation_2019_11_wa001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_wa001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_wa002`
--

DROP TABLE IF EXISTS `preparation_2019_11_wa002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_wa002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_wa003`
--

DROP TABLE IF EXISTS `preparation_2019_11_wa003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_wa003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_11_wa004`
--

DROP TABLE IF EXISTS `preparation_2019_11_wa004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_11_wa004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_ac001`
--

DROP TABLE IF EXISTS `preparation_2019_12_ac001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_ac001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_ac002`
--

DROP TABLE IF EXISTS `preparation_2019_12_ac002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_ac002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_ac003`
--

DROP TABLE IF EXISTS `preparation_2019_12_ac003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_ac003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_ac004`
--

DROP TABLE IF EXISTS `preparation_2019_12_ac004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_ac004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_ac005`
--

DROP TABLE IF EXISTS `preparation_2019_12_ac005`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_ac005` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_ac006`
--

DROP TABLE IF EXISTS `preparation_2019_12_ac006`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_ac006` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_ac007`
--

DROP TABLE IF EXISTS `preparation_2019_12_ac007`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_ac007` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_ac008`
--

DROP TABLE IF EXISTS `preparation_2019_12_ac008`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_ac008` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_ac009`
--

DROP TABLE IF EXISTS `preparation_2019_12_ac009`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_ac009` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_ac010`
--

DROP TABLE IF EXISTS `preparation_2019_12_ac010`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_ac010` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_ac011`
--

DROP TABLE IF EXISTS `preparation_2019_12_ac011`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_ac011` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_ac012`
--

DROP TABLE IF EXISTS `preparation_2019_12_ac012`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_ac012` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_ac013`
--

DROP TABLE IF EXISTS `preparation_2019_12_ac013`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_ac013` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_ca001`
--

DROP TABLE IF EXISTS `preparation_2019_12_ca001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_ca001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_ca002`
--

DROP TABLE IF EXISTS `preparation_2019_12_ca002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_ca002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_ca003`
--

DROP TABLE IF EXISTS `preparation_2019_12_ca003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_ca003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_ca004`
--

DROP TABLE IF EXISTS `preparation_2019_12_ca004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_ca004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_cd001`
--

DROP TABLE IF EXISTS `preparation_2019_12_cd001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_cd001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_cd002`
--

DROP TABLE IF EXISTS `preparation_2019_12_cd002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_cd002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_cd003`
--

DROP TABLE IF EXISTS `preparation_2019_12_cd003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_cd003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_cd004`
--

DROP TABLE IF EXISTS `preparation_2019_12_cd004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_cd004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_cl001`
--

DROP TABLE IF EXISTS `preparation_2019_12_cl001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_cl001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_el001`
--

DROP TABLE IF EXISTS `preparation_2019_12_el001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_el001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_el002`
--

DROP TABLE IF EXISTS `preparation_2019_12_el002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_el002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_el003`
--

DROP TABLE IF EXISTS `preparation_2019_12_el003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_el003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_el004`
--

DROP TABLE IF EXISTS `preparation_2019_12_el004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_el004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_el005`
--

DROP TABLE IF EXISTS `preparation_2019_12_el005`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_el005` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_el006`
--

DROP TABLE IF EXISTS `preparation_2019_12_el006`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_el006` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_el007`
--

DROP TABLE IF EXISTS `preparation_2019_12_el007`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_el007` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_el008`
--

DROP TABLE IF EXISTS `preparation_2019_12_el008`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_el008` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_el009`
--

DROP TABLE IF EXISTS `preparation_2019_12_el009`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_el009` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_el010`
--

DROP TABLE IF EXISTS `preparation_2019_12_el010`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_el010` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_el011`
--

DROP TABLE IF EXISTS `preparation_2019_12_el011`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_el011` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_el012`
--

DROP TABLE IF EXISTS `preparation_2019_12_el012`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_el012` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_el013`
--

DROP TABLE IF EXISTS `preparation_2019_12_el013`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_el013` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_el014`
--

DROP TABLE IF EXISTS `preparation_2019_12_el014`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_el014` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_el015`
--

DROP TABLE IF EXISTS `preparation_2019_12_el015`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_el015` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_el016`
--

DROP TABLE IF EXISTS `preparation_2019_12_el016`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_el016` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_el017`
--

DROP TABLE IF EXISTS `preparation_2019_12_el017`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_el017` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_el018`
--

DROP TABLE IF EXISTS `preparation_2019_12_el018`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_el018` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_el019`
--

DROP TABLE IF EXISTS `preparation_2019_12_el019`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_el019` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_el020`
--

DROP TABLE IF EXISTS `preparation_2019_12_el020`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_el020` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_el021`
--

DROP TABLE IF EXISTS `preparation_2019_12_el021`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_el021` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_el022`
--

DROP TABLE IF EXISTS `preparation_2019_12_el022`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_el022` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_el023`
--

DROP TABLE IF EXISTS `preparation_2019_12_el023`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_el023` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_el024`
--

DROP TABLE IF EXISTS `preparation_2019_12_el024`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_el024` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_ga001`
--

DROP TABLE IF EXISTS `preparation_2019_12_ga001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_ga001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_ga002`
--

DROP TABLE IF EXISTS `preparation_2019_12_ga002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_ga002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_ga003`
--

DROP TABLE IF EXISTS `preparation_2019_12_ga003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_ga003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_ga004`
--

DROP TABLE IF EXISTS `preparation_2019_12_ga004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_ga004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_nt001`
--

DROP TABLE IF EXISTS `preparation_2019_12_nt001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_nt001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_nt002`
--

DROP TABLE IF EXISTS `preparation_2019_12_nt002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_nt002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_nt003`
--

DROP TABLE IF EXISTS `preparation_2019_12_nt003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_nt003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_nt004`
--

DROP TABLE IF EXISTS `preparation_2019_12_nt004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_nt004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_ox001`
--

DROP TABLE IF EXISTS `preparation_2019_12_ox001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_ox001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_ox002`
--

DROP TABLE IF EXISTS `preparation_2019_12_ox002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_ox002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_ox003`
--

DROP TABLE IF EXISTS `preparation_2019_12_ox003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_ox003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_ox004`
--

DROP TABLE IF EXISTS `preparation_2019_12_ox004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_ox004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_st001`
--

DROP TABLE IF EXISTS `preparation_2019_12_st001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_st001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_st002`
--

DROP TABLE IF EXISTS `preparation_2019_12_st002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_st002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_st003`
--

DROP TABLE IF EXISTS `preparation_2019_12_st003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_st003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_st004`
--

DROP TABLE IF EXISTS `preparation_2019_12_st004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_st004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_wa001`
--

DROP TABLE IF EXISTS `preparation_2019_12_wa001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_wa001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_wa002`
--

DROP TABLE IF EXISTS `preparation_2019_12_wa002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_wa002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_wa003`
--

DROP TABLE IF EXISTS `preparation_2019_12_wa003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_wa003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2019_12_wa004`
--

DROP TABLE IF EXISTS `preparation_2019_12_wa004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2019_12_wa004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_ac001`
--

DROP TABLE IF EXISTS `preparation_2020_01_ac001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_ac001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_ac002`
--

DROP TABLE IF EXISTS `preparation_2020_01_ac002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_ac002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_ac003`
--

DROP TABLE IF EXISTS `preparation_2020_01_ac003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_ac003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_ac004`
--

DROP TABLE IF EXISTS `preparation_2020_01_ac004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_ac004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_ac005`
--

DROP TABLE IF EXISTS `preparation_2020_01_ac005`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_ac005` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_ac006`
--

DROP TABLE IF EXISTS `preparation_2020_01_ac006`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_ac006` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_ac007`
--

DROP TABLE IF EXISTS `preparation_2020_01_ac007`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_ac007` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_ac008`
--

DROP TABLE IF EXISTS `preparation_2020_01_ac008`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_ac008` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_ac009`
--

DROP TABLE IF EXISTS `preparation_2020_01_ac009`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_ac009` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_ac010`
--

DROP TABLE IF EXISTS `preparation_2020_01_ac010`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_ac010` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_ac011`
--

DROP TABLE IF EXISTS `preparation_2020_01_ac011`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_ac011` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_ac012`
--

DROP TABLE IF EXISTS `preparation_2020_01_ac012`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_ac012` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_ac013`
--

DROP TABLE IF EXISTS `preparation_2020_01_ac013`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_ac013` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_ca001`
--

DROP TABLE IF EXISTS `preparation_2020_01_ca001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_ca001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_ca002`
--

DROP TABLE IF EXISTS `preparation_2020_01_ca002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_ca002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_ca003`
--

DROP TABLE IF EXISTS `preparation_2020_01_ca003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_ca003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_ca004`
--

DROP TABLE IF EXISTS `preparation_2020_01_ca004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_ca004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_cd001`
--

DROP TABLE IF EXISTS `preparation_2020_01_cd001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_cd001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_cd002`
--

DROP TABLE IF EXISTS `preparation_2020_01_cd002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_cd002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_cd003`
--

DROP TABLE IF EXISTS `preparation_2020_01_cd003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_cd003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_cd004`
--

DROP TABLE IF EXISTS `preparation_2020_01_cd004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_cd004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_cl001`
--

DROP TABLE IF EXISTS `preparation_2020_01_cl001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_cl001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_el001`
--

DROP TABLE IF EXISTS `preparation_2020_01_el001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_el001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_el002`
--

DROP TABLE IF EXISTS `preparation_2020_01_el002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_el002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_el003`
--

DROP TABLE IF EXISTS `preparation_2020_01_el003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_el003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_el004`
--

DROP TABLE IF EXISTS `preparation_2020_01_el004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_el004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_el005`
--

DROP TABLE IF EXISTS `preparation_2020_01_el005`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_el005` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_el006`
--

DROP TABLE IF EXISTS `preparation_2020_01_el006`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_el006` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_el007`
--

DROP TABLE IF EXISTS `preparation_2020_01_el007`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_el007` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_el008`
--

DROP TABLE IF EXISTS `preparation_2020_01_el008`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_el008` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_el009`
--

DROP TABLE IF EXISTS `preparation_2020_01_el009`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_el009` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_el010`
--

DROP TABLE IF EXISTS `preparation_2020_01_el010`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_el010` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_el011`
--

DROP TABLE IF EXISTS `preparation_2020_01_el011`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_el011` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_el012`
--

DROP TABLE IF EXISTS `preparation_2020_01_el012`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_el012` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_el013`
--

DROP TABLE IF EXISTS `preparation_2020_01_el013`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_el013` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_el014`
--

DROP TABLE IF EXISTS `preparation_2020_01_el014`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_el014` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_el015`
--

DROP TABLE IF EXISTS `preparation_2020_01_el015`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_el015` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_el016`
--

DROP TABLE IF EXISTS `preparation_2020_01_el016`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_el016` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_el017`
--

DROP TABLE IF EXISTS `preparation_2020_01_el017`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_el017` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_el018`
--

DROP TABLE IF EXISTS `preparation_2020_01_el018`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_el018` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_el019`
--

DROP TABLE IF EXISTS `preparation_2020_01_el019`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_el019` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_el020`
--

DROP TABLE IF EXISTS `preparation_2020_01_el020`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_el020` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_el021`
--

DROP TABLE IF EXISTS `preparation_2020_01_el021`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_el021` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_el022`
--

DROP TABLE IF EXISTS `preparation_2020_01_el022`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_el022` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_el023`
--

DROP TABLE IF EXISTS `preparation_2020_01_el023`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_el023` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_el024`
--

DROP TABLE IF EXISTS `preparation_2020_01_el024`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_el024` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_ga001`
--

DROP TABLE IF EXISTS `preparation_2020_01_ga001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_ga001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_ga002`
--

DROP TABLE IF EXISTS `preparation_2020_01_ga002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_ga002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_ga003`
--

DROP TABLE IF EXISTS `preparation_2020_01_ga003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_ga003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_ga004`
--

DROP TABLE IF EXISTS `preparation_2020_01_ga004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_ga004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_nt001`
--

DROP TABLE IF EXISTS `preparation_2020_01_nt001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_nt001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_nt002`
--

DROP TABLE IF EXISTS `preparation_2020_01_nt002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_nt002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_nt003`
--

DROP TABLE IF EXISTS `preparation_2020_01_nt003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_nt003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_nt004`
--

DROP TABLE IF EXISTS `preparation_2020_01_nt004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_nt004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_ox001`
--

DROP TABLE IF EXISTS `preparation_2020_01_ox001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_ox001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_ox002`
--

DROP TABLE IF EXISTS `preparation_2020_01_ox002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_ox002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_ox003`
--

DROP TABLE IF EXISTS `preparation_2020_01_ox003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_ox003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_ox004`
--

DROP TABLE IF EXISTS `preparation_2020_01_ox004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_ox004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_st001`
--

DROP TABLE IF EXISTS `preparation_2020_01_st001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_st001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_st002`
--

DROP TABLE IF EXISTS `preparation_2020_01_st002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_st002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_st003`
--

DROP TABLE IF EXISTS `preparation_2020_01_st003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_st003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_st004`
--

DROP TABLE IF EXISTS `preparation_2020_01_st004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_st004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_wa001`
--

DROP TABLE IF EXISTS `preparation_2020_01_wa001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_wa001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_wa002`
--

DROP TABLE IF EXISTS `preparation_2020_01_wa002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_wa002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_wa003`
--

DROP TABLE IF EXISTS `preparation_2020_01_wa003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_wa003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_01_wa004`
--

DROP TABLE IF EXISTS `preparation_2020_01_wa004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_01_wa004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_ac001`
--

DROP TABLE IF EXISTS `preparation_2020_02_ac001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_ac001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_ac002`
--

DROP TABLE IF EXISTS `preparation_2020_02_ac002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_ac002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_ac003`
--

DROP TABLE IF EXISTS `preparation_2020_02_ac003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_ac003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_ac004`
--

DROP TABLE IF EXISTS `preparation_2020_02_ac004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_ac004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_ac005`
--

DROP TABLE IF EXISTS `preparation_2020_02_ac005`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_ac005` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_ac006`
--

DROP TABLE IF EXISTS `preparation_2020_02_ac006`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_ac006` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_ac007`
--

DROP TABLE IF EXISTS `preparation_2020_02_ac007`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_ac007` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_ac008`
--

DROP TABLE IF EXISTS `preparation_2020_02_ac008`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_ac008` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_ac009`
--

DROP TABLE IF EXISTS `preparation_2020_02_ac009`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_ac009` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_ac010`
--

DROP TABLE IF EXISTS `preparation_2020_02_ac010`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_ac010` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_ac011`
--

DROP TABLE IF EXISTS `preparation_2020_02_ac011`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_ac011` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_ac012`
--

DROP TABLE IF EXISTS `preparation_2020_02_ac012`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_ac012` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_ac013`
--

DROP TABLE IF EXISTS `preparation_2020_02_ac013`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_ac013` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_ca001`
--

DROP TABLE IF EXISTS `preparation_2020_02_ca001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_ca001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_ca002`
--

DROP TABLE IF EXISTS `preparation_2020_02_ca002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_ca002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_ca003`
--

DROP TABLE IF EXISTS `preparation_2020_02_ca003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_ca003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_ca004`
--

DROP TABLE IF EXISTS `preparation_2020_02_ca004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_ca004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_cd001`
--

DROP TABLE IF EXISTS `preparation_2020_02_cd001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_cd001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_cd002`
--

DROP TABLE IF EXISTS `preparation_2020_02_cd002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_cd002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_cd003`
--

DROP TABLE IF EXISTS `preparation_2020_02_cd003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_cd003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_cd004`
--

DROP TABLE IF EXISTS `preparation_2020_02_cd004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_cd004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_cl001`
--

DROP TABLE IF EXISTS `preparation_2020_02_cl001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_cl001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_el001`
--

DROP TABLE IF EXISTS `preparation_2020_02_el001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_el001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_el002`
--

DROP TABLE IF EXISTS `preparation_2020_02_el002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_el002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_el003`
--

DROP TABLE IF EXISTS `preparation_2020_02_el003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_el003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_el004`
--

DROP TABLE IF EXISTS `preparation_2020_02_el004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_el004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_el005`
--

DROP TABLE IF EXISTS `preparation_2020_02_el005`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_el005` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_el006`
--

DROP TABLE IF EXISTS `preparation_2020_02_el006`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_el006` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_el007`
--

DROP TABLE IF EXISTS `preparation_2020_02_el007`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_el007` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_el008`
--

DROP TABLE IF EXISTS `preparation_2020_02_el008`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_el008` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_el009`
--

DROP TABLE IF EXISTS `preparation_2020_02_el009`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_el009` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_el010`
--

DROP TABLE IF EXISTS `preparation_2020_02_el010`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_el010` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_el011`
--

DROP TABLE IF EXISTS `preparation_2020_02_el011`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_el011` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_el012`
--

DROP TABLE IF EXISTS `preparation_2020_02_el012`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_el012` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_el013`
--

DROP TABLE IF EXISTS `preparation_2020_02_el013`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_el013` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_el014`
--

DROP TABLE IF EXISTS `preparation_2020_02_el014`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_el014` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_el015`
--

DROP TABLE IF EXISTS `preparation_2020_02_el015`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_el015` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_el016`
--

DROP TABLE IF EXISTS `preparation_2020_02_el016`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_el016` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_el017`
--

DROP TABLE IF EXISTS `preparation_2020_02_el017`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_el017` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_el018`
--

DROP TABLE IF EXISTS `preparation_2020_02_el018`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_el018` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_el019`
--

DROP TABLE IF EXISTS `preparation_2020_02_el019`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_el019` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_el020`
--

DROP TABLE IF EXISTS `preparation_2020_02_el020`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_el020` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_el021`
--

DROP TABLE IF EXISTS `preparation_2020_02_el021`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_el021` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_el022`
--

DROP TABLE IF EXISTS `preparation_2020_02_el022`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_el022` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_el023`
--

DROP TABLE IF EXISTS `preparation_2020_02_el023`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_el023` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_el024`
--

DROP TABLE IF EXISTS `preparation_2020_02_el024`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_el024` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_ga001`
--

DROP TABLE IF EXISTS `preparation_2020_02_ga001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_ga001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_ga002`
--

DROP TABLE IF EXISTS `preparation_2020_02_ga002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_ga002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_ga003`
--

DROP TABLE IF EXISTS `preparation_2020_02_ga003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_ga003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_ga004`
--

DROP TABLE IF EXISTS `preparation_2020_02_ga004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_ga004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_nt001`
--

DROP TABLE IF EXISTS `preparation_2020_02_nt001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_nt001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_nt002`
--

DROP TABLE IF EXISTS `preparation_2020_02_nt002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_nt002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_nt003`
--

DROP TABLE IF EXISTS `preparation_2020_02_nt003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_nt003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_nt004`
--

DROP TABLE IF EXISTS `preparation_2020_02_nt004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_nt004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_ox001`
--

DROP TABLE IF EXISTS `preparation_2020_02_ox001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_ox001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_ox002`
--

DROP TABLE IF EXISTS `preparation_2020_02_ox002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_ox002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_ox003`
--

DROP TABLE IF EXISTS `preparation_2020_02_ox003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_ox003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_ox004`
--

DROP TABLE IF EXISTS `preparation_2020_02_ox004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_ox004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_st001`
--

DROP TABLE IF EXISTS `preparation_2020_02_st001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_st001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_st002`
--

DROP TABLE IF EXISTS `preparation_2020_02_st002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_st002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_st003`
--

DROP TABLE IF EXISTS `preparation_2020_02_st003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_st003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_st004`
--

DROP TABLE IF EXISTS `preparation_2020_02_st004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_st004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_wa001`
--

DROP TABLE IF EXISTS `preparation_2020_02_wa001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_wa001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_wa002`
--

DROP TABLE IF EXISTS `preparation_2020_02_wa002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_wa002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_wa003`
--

DROP TABLE IF EXISTS `preparation_2020_02_wa003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_wa003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_02_wa004`
--

DROP TABLE IF EXISTS `preparation_2020_02_wa004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_02_wa004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_ac001`
--

DROP TABLE IF EXISTS `preparation_2020_03_ac001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_ac001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_ac002`
--

DROP TABLE IF EXISTS `preparation_2020_03_ac002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_ac002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_ac003`
--

DROP TABLE IF EXISTS `preparation_2020_03_ac003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_ac003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_ac004`
--

DROP TABLE IF EXISTS `preparation_2020_03_ac004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_ac004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_ac005`
--

DROP TABLE IF EXISTS `preparation_2020_03_ac005`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_ac005` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_ac006`
--

DROP TABLE IF EXISTS `preparation_2020_03_ac006`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_ac006` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_ac007`
--

DROP TABLE IF EXISTS `preparation_2020_03_ac007`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_ac007` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_ac008`
--

DROP TABLE IF EXISTS `preparation_2020_03_ac008`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_ac008` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_ac009`
--

DROP TABLE IF EXISTS `preparation_2020_03_ac009`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_ac009` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_ac010`
--

DROP TABLE IF EXISTS `preparation_2020_03_ac010`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_ac010` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_ac011`
--

DROP TABLE IF EXISTS `preparation_2020_03_ac011`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_ac011` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_ac012`
--

DROP TABLE IF EXISTS `preparation_2020_03_ac012`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_ac012` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_ac013`
--

DROP TABLE IF EXISTS `preparation_2020_03_ac013`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_ac013` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_ca001`
--

DROP TABLE IF EXISTS `preparation_2020_03_ca001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_ca001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_ca002`
--

DROP TABLE IF EXISTS `preparation_2020_03_ca002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_ca002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_ca003`
--

DROP TABLE IF EXISTS `preparation_2020_03_ca003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_ca003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_ca004`
--

DROP TABLE IF EXISTS `preparation_2020_03_ca004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_ca004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_cd001`
--

DROP TABLE IF EXISTS `preparation_2020_03_cd001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_cd001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_cd002`
--

DROP TABLE IF EXISTS `preparation_2020_03_cd002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_cd002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_cd003`
--

DROP TABLE IF EXISTS `preparation_2020_03_cd003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_cd003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_cd004`
--

DROP TABLE IF EXISTS `preparation_2020_03_cd004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_cd004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_cl001`
--

DROP TABLE IF EXISTS `preparation_2020_03_cl001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_cl001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_el001`
--

DROP TABLE IF EXISTS `preparation_2020_03_el001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_el001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_el002`
--

DROP TABLE IF EXISTS `preparation_2020_03_el002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_el002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_el003`
--

DROP TABLE IF EXISTS `preparation_2020_03_el003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_el003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_el004`
--

DROP TABLE IF EXISTS `preparation_2020_03_el004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_el004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_el005`
--

DROP TABLE IF EXISTS `preparation_2020_03_el005`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_el005` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_el006`
--

DROP TABLE IF EXISTS `preparation_2020_03_el006`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_el006` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_el007`
--

DROP TABLE IF EXISTS `preparation_2020_03_el007`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_el007` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_el008`
--

DROP TABLE IF EXISTS `preparation_2020_03_el008`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_el008` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_el009`
--

DROP TABLE IF EXISTS `preparation_2020_03_el009`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_el009` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_el010`
--

DROP TABLE IF EXISTS `preparation_2020_03_el010`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_el010` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_el011`
--

DROP TABLE IF EXISTS `preparation_2020_03_el011`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_el011` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_el012`
--

DROP TABLE IF EXISTS `preparation_2020_03_el012`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_el012` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_el013`
--

DROP TABLE IF EXISTS `preparation_2020_03_el013`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_el013` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_el014`
--

DROP TABLE IF EXISTS `preparation_2020_03_el014`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_el014` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_el015`
--

DROP TABLE IF EXISTS `preparation_2020_03_el015`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_el015` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_el016`
--

DROP TABLE IF EXISTS `preparation_2020_03_el016`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_el016` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_el017`
--

DROP TABLE IF EXISTS `preparation_2020_03_el017`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_el017` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_el018`
--

DROP TABLE IF EXISTS `preparation_2020_03_el018`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_el018` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_el019`
--

DROP TABLE IF EXISTS `preparation_2020_03_el019`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_el019` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_el020`
--

DROP TABLE IF EXISTS `preparation_2020_03_el020`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_el020` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_el021`
--

DROP TABLE IF EXISTS `preparation_2020_03_el021`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_el021` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_el022`
--

DROP TABLE IF EXISTS `preparation_2020_03_el022`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_el022` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_el023`
--

DROP TABLE IF EXISTS `preparation_2020_03_el023`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_el023` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_el024`
--

DROP TABLE IF EXISTS `preparation_2020_03_el024`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_el024` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_ga001`
--

DROP TABLE IF EXISTS `preparation_2020_03_ga001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_ga001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_ga002`
--

DROP TABLE IF EXISTS `preparation_2020_03_ga002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_ga002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_ga003`
--

DROP TABLE IF EXISTS `preparation_2020_03_ga003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_ga003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_ga004`
--

DROP TABLE IF EXISTS `preparation_2020_03_ga004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_ga004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_nt001`
--

DROP TABLE IF EXISTS `preparation_2020_03_nt001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_nt001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_nt002`
--

DROP TABLE IF EXISTS `preparation_2020_03_nt002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_nt002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_nt003`
--

DROP TABLE IF EXISTS `preparation_2020_03_nt003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_nt003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_nt004`
--

DROP TABLE IF EXISTS `preparation_2020_03_nt004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_nt004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_ox001`
--

DROP TABLE IF EXISTS `preparation_2020_03_ox001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_ox001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_ox002`
--

DROP TABLE IF EXISTS `preparation_2020_03_ox002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_ox002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_ox003`
--

DROP TABLE IF EXISTS `preparation_2020_03_ox003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_ox003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_ox004`
--

DROP TABLE IF EXISTS `preparation_2020_03_ox004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_ox004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_st001`
--

DROP TABLE IF EXISTS `preparation_2020_03_st001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_st001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_st002`
--

DROP TABLE IF EXISTS `preparation_2020_03_st002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_st002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_st003`
--

DROP TABLE IF EXISTS `preparation_2020_03_st003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_st003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_st004`
--

DROP TABLE IF EXISTS `preparation_2020_03_st004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_st004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_wa001`
--

DROP TABLE IF EXISTS `preparation_2020_03_wa001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_wa001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_wa002`
--

DROP TABLE IF EXISTS `preparation_2020_03_wa002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_wa002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_wa003`
--

DROP TABLE IF EXISTS `preparation_2020_03_wa003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_wa003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_03_wa004`
--

DROP TABLE IF EXISTS `preparation_2020_03_wa004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_03_wa004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_ac001`
--

DROP TABLE IF EXISTS `preparation_2020_04_ac001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_ac001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_ac002`
--

DROP TABLE IF EXISTS `preparation_2020_04_ac002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_ac002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_ac003`
--

DROP TABLE IF EXISTS `preparation_2020_04_ac003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_ac003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_ac004`
--

DROP TABLE IF EXISTS `preparation_2020_04_ac004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_ac004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_ac005`
--

DROP TABLE IF EXISTS `preparation_2020_04_ac005`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_ac005` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_ac006`
--

DROP TABLE IF EXISTS `preparation_2020_04_ac006`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_ac006` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_ac007`
--

DROP TABLE IF EXISTS `preparation_2020_04_ac007`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_ac007` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_ac008`
--

DROP TABLE IF EXISTS `preparation_2020_04_ac008`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_ac008` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_ac009`
--

DROP TABLE IF EXISTS `preparation_2020_04_ac009`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_ac009` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_ac010`
--

DROP TABLE IF EXISTS `preparation_2020_04_ac010`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_ac010` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_ac011`
--

DROP TABLE IF EXISTS `preparation_2020_04_ac011`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_ac011` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_ac012`
--

DROP TABLE IF EXISTS `preparation_2020_04_ac012`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_ac012` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_ac013`
--

DROP TABLE IF EXISTS `preparation_2020_04_ac013`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_ac013` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_ca001`
--

DROP TABLE IF EXISTS `preparation_2020_04_ca001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_ca001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_ca002`
--

DROP TABLE IF EXISTS `preparation_2020_04_ca002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_ca002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_ca003`
--

DROP TABLE IF EXISTS `preparation_2020_04_ca003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_ca003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_ca004`
--

DROP TABLE IF EXISTS `preparation_2020_04_ca004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_ca004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_cd001`
--

DROP TABLE IF EXISTS `preparation_2020_04_cd001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_cd001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_cd002`
--

DROP TABLE IF EXISTS `preparation_2020_04_cd002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_cd002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_cd003`
--

DROP TABLE IF EXISTS `preparation_2020_04_cd003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_cd003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_cd004`
--

DROP TABLE IF EXISTS `preparation_2020_04_cd004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_cd004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_cl001`
--

DROP TABLE IF EXISTS `preparation_2020_04_cl001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_cl001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_el001`
--

DROP TABLE IF EXISTS `preparation_2020_04_el001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_el001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_el002`
--

DROP TABLE IF EXISTS `preparation_2020_04_el002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_el002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_el003`
--

DROP TABLE IF EXISTS `preparation_2020_04_el003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_el003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_el004`
--

DROP TABLE IF EXISTS `preparation_2020_04_el004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_el004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_el005`
--

DROP TABLE IF EXISTS `preparation_2020_04_el005`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_el005` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_el006`
--

DROP TABLE IF EXISTS `preparation_2020_04_el006`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_el006` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_el007`
--

DROP TABLE IF EXISTS `preparation_2020_04_el007`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_el007` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_el008`
--

DROP TABLE IF EXISTS `preparation_2020_04_el008`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_el008` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_el009`
--

DROP TABLE IF EXISTS `preparation_2020_04_el009`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_el009` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_el010`
--

DROP TABLE IF EXISTS `preparation_2020_04_el010`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_el010` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_el011`
--

DROP TABLE IF EXISTS `preparation_2020_04_el011`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_el011` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_el012`
--

DROP TABLE IF EXISTS `preparation_2020_04_el012`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_el012` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_el013`
--

DROP TABLE IF EXISTS `preparation_2020_04_el013`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_el013` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_el014`
--

DROP TABLE IF EXISTS `preparation_2020_04_el014`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_el014` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_el015`
--

DROP TABLE IF EXISTS `preparation_2020_04_el015`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_el015` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_el016`
--

DROP TABLE IF EXISTS `preparation_2020_04_el016`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_el016` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_el017`
--

DROP TABLE IF EXISTS `preparation_2020_04_el017`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_el017` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_el018`
--

DROP TABLE IF EXISTS `preparation_2020_04_el018`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_el018` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_el019`
--

DROP TABLE IF EXISTS `preparation_2020_04_el019`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_el019` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_el020`
--

DROP TABLE IF EXISTS `preparation_2020_04_el020`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_el020` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_el021`
--

DROP TABLE IF EXISTS `preparation_2020_04_el021`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_el021` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_el022`
--

DROP TABLE IF EXISTS `preparation_2020_04_el022`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_el022` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_el023`
--

DROP TABLE IF EXISTS `preparation_2020_04_el023`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_el023` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_el024`
--

DROP TABLE IF EXISTS `preparation_2020_04_el024`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_el024` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_ga001`
--

DROP TABLE IF EXISTS `preparation_2020_04_ga001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_ga001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_ga002`
--

DROP TABLE IF EXISTS `preparation_2020_04_ga002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_ga002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_ga003`
--

DROP TABLE IF EXISTS `preparation_2020_04_ga003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_ga003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_ga004`
--

DROP TABLE IF EXISTS `preparation_2020_04_ga004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_ga004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_nt001`
--

DROP TABLE IF EXISTS `preparation_2020_04_nt001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_nt001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_nt002`
--

DROP TABLE IF EXISTS `preparation_2020_04_nt002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_nt002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_nt003`
--

DROP TABLE IF EXISTS `preparation_2020_04_nt003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_nt003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_nt004`
--

DROP TABLE IF EXISTS `preparation_2020_04_nt004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_nt004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_ox001`
--

DROP TABLE IF EXISTS `preparation_2020_04_ox001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_ox001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_ox002`
--

DROP TABLE IF EXISTS `preparation_2020_04_ox002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_ox002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_ox003`
--

DROP TABLE IF EXISTS `preparation_2020_04_ox003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_ox003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_ox004`
--

DROP TABLE IF EXISTS `preparation_2020_04_ox004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_ox004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_st001`
--

DROP TABLE IF EXISTS `preparation_2020_04_st001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_st001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_st002`
--

DROP TABLE IF EXISTS `preparation_2020_04_st002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_st002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_st003`
--

DROP TABLE IF EXISTS `preparation_2020_04_st003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_st003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_st004`
--

DROP TABLE IF EXISTS `preparation_2020_04_st004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_st004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_wa001`
--

DROP TABLE IF EXISTS `preparation_2020_04_wa001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_wa001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_wa002`
--

DROP TABLE IF EXISTS `preparation_2020_04_wa002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_wa002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_wa003`
--

DROP TABLE IF EXISTS `preparation_2020_04_wa003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_wa003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_04_wa004`
--

DROP TABLE IF EXISTS `preparation_2020_04_wa004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_04_wa004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_ac001`
--

DROP TABLE IF EXISTS `preparation_2020_05_ac001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_ac001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_ac002`
--

DROP TABLE IF EXISTS `preparation_2020_05_ac002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_ac002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_ac003`
--

DROP TABLE IF EXISTS `preparation_2020_05_ac003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_ac003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_ac004`
--

DROP TABLE IF EXISTS `preparation_2020_05_ac004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_ac004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_ac005`
--

DROP TABLE IF EXISTS `preparation_2020_05_ac005`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_ac005` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_ac006`
--

DROP TABLE IF EXISTS `preparation_2020_05_ac006`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_ac006` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_ac007`
--

DROP TABLE IF EXISTS `preparation_2020_05_ac007`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_ac007` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_ac008`
--

DROP TABLE IF EXISTS `preparation_2020_05_ac008`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_ac008` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_ac009`
--

DROP TABLE IF EXISTS `preparation_2020_05_ac009`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_ac009` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_ac010`
--

DROP TABLE IF EXISTS `preparation_2020_05_ac010`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_ac010` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_ac011`
--

DROP TABLE IF EXISTS `preparation_2020_05_ac011`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_ac011` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_ac012`
--

DROP TABLE IF EXISTS `preparation_2020_05_ac012`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_ac012` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_ac013`
--

DROP TABLE IF EXISTS `preparation_2020_05_ac013`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_ac013` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_ca001`
--

DROP TABLE IF EXISTS `preparation_2020_05_ca001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_ca001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_ca002`
--

DROP TABLE IF EXISTS `preparation_2020_05_ca002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_ca002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_ca003`
--

DROP TABLE IF EXISTS `preparation_2020_05_ca003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_ca003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_ca004`
--

DROP TABLE IF EXISTS `preparation_2020_05_ca004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_ca004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_cd001`
--

DROP TABLE IF EXISTS `preparation_2020_05_cd001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_cd001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_cd002`
--

DROP TABLE IF EXISTS `preparation_2020_05_cd002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_cd002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_cd003`
--

DROP TABLE IF EXISTS `preparation_2020_05_cd003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_cd003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_cd004`
--

DROP TABLE IF EXISTS `preparation_2020_05_cd004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_cd004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_cl001`
--

DROP TABLE IF EXISTS `preparation_2020_05_cl001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_cl001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_el001`
--

DROP TABLE IF EXISTS `preparation_2020_05_el001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_el001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_el002`
--

DROP TABLE IF EXISTS `preparation_2020_05_el002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_el002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_el003`
--

DROP TABLE IF EXISTS `preparation_2020_05_el003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_el003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_el004`
--

DROP TABLE IF EXISTS `preparation_2020_05_el004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_el004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_el005`
--

DROP TABLE IF EXISTS `preparation_2020_05_el005`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_el005` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_el006`
--

DROP TABLE IF EXISTS `preparation_2020_05_el006`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_el006` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_el007`
--

DROP TABLE IF EXISTS `preparation_2020_05_el007`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_el007` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_el008`
--

DROP TABLE IF EXISTS `preparation_2020_05_el008`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_el008` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_el009`
--

DROP TABLE IF EXISTS `preparation_2020_05_el009`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_el009` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_el010`
--

DROP TABLE IF EXISTS `preparation_2020_05_el010`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_el010` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_el011`
--

DROP TABLE IF EXISTS `preparation_2020_05_el011`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_el011` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_el012`
--

DROP TABLE IF EXISTS `preparation_2020_05_el012`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_el012` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_el013`
--

DROP TABLE IF EXISTS `preparation_2020_05_el013`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_el013` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_el014`
--

DROP TABLE IF EXISTS `preparation_2020_05_el014`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_el014` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_el015`
--

DROP TABLE IF EXISTS `preparation_2020_05_el015`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_el015` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_el016`
--

DROP TABLE IF EXISTS `preparation_2020_05_el016`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_el016` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_el017`
--

DROP TABLE IF EXISTS `preparation_2020_05_el017`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_el017` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_el018`
--

DROP TABLE IF EXISTS `preparation_2020_05_el018`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_el018` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_el019`
--

DROP TABLE IF EXISTS `preparation_2020_05_el019`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_el019` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_el020`
--

DROP TABLE IF EXISTS `preparation_2020_05_el020`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_el020` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_el021`
--

DROP TABLE IF EXISTS `preparation_2020_05_el021`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_el021` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_el022`
--

DROP TABLE IF EXISTS `preparation_2020_05_el022`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_el022` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_el023`
--

DROP TABLE IF EXISTS `preparation_2020_05_el023`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_el023` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_el024`
--

DROP TABLE IF EXISTS `preparation_2020_05_el024`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_el024` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_ga001`
--

DROP TABLE IF EXISTS `preparation_2020_05_ga001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_ga001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_ga002`
--

DROP TABLE IF EXISTS `preparation_2020_05_ga002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_ga002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_ga003`
--

DROP TABLE IF EXISTS `preparation_2020_05_ga003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_ga003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_ga004`
--

DROP TABLE IF EXISTS `preparation_2020_05_ga004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_ga004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_nt001`
--

DROP TABLE IF EXISTS `preparation_2020_05_nt001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_nt001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_nt002`
--

DROP TABLE IF EXISTS `preparation_2020_05_nt002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_nt002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_nt003`
--

DROP TABLE IF EXISTS `preparation_2020_05_nt003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_nt003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_nt004`
--

DROP TABLE IF EXISTS `preparation_2020_05_nt004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_nt004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_ox001`
--

DROP TABLE IF EXISTS `preparation_2020_05_ox001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_ox001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_ox002`
--

DROP TABLE IF EXISTS `preparation_2020_05_ox002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_ox002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_ox003`
--

DROP TABLE IF EXISTS `preparation_2020_05_ox003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_ox003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_ox004`
--

DROP TABLE IF EXISTS `preparation_2020_05_ox004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_ox004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_st001`
--

DROP TABLE IF EXISTS `preparation_2020_05_st001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_st001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_st002`
--

DROP TABLE IF EXISTS `preparation_2020_05_st002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_st002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_st003`
--

DROP TABLE IF EXISTS `preparation_2020_05_st003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_st003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_st004`
--

DROP TABLE IF EXISTS `preparation_2020_05_st004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_st004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_wa001`
--

DROP TABLE IF EXISTS `preparation_2020_05_wa001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_wa001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_wa002`
--

DROP TABLE IF EXISTS `preparation_2020_05_wa002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_wa002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_wa003`
--

DROP TABLE IF EXISTS `preparation_2020_05_wa003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_wa003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_05_wa004`
--

DROP TABLE IF EXISTS `preparation_2020_05_wa004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_05_wa004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_ac001`
--

DROP TABLE IF EXISTS `preparation_2020_06_ac001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_ac001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_ac002`
--

DROP TABLE IF EXISTS `preparation_2020_06_ac002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_ac002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_ac003`
--

DROP TABLE IF EXISTS `preparation_2020_06_ac003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_ac003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_ac004`
--

DROP TABLE IF EXISTS `preparation_2020_06_ac004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_ac004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_ac005`
--

DROP TABLE IF EXISTS `preparation_2020_06_ac005`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_ac005` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_ac006`
--

DROP TABLE IF EXISTS `preparation_2020_06_ac006`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_ac006` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_ac007`
--

DROP TABLE IF EXISTS `preparation_2020_06_ac007`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_ac007` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_ac008`
--

DROP TABLE IF EXISTS `preparation_2020_06_ac008`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_ac008` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_ac009`
--

DROP TABLE IF EXISTS `preparation_2020_06_ac009`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_ac009` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_ac010`
--

DROP TABLE IF EXISTS `preparation_2020_06_ac010`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_ac010` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_ac011`
--

DROP TABLE IF EXISTS `preparation_2020_06_ac011`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_ac011` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_ac012`
--

DROP TABLE IF EXISTS `preparation_2020_06_ac012`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_ac012` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_ac013`
--

DROP TABLE IF EXISTS `preparation_2020_06_ac013`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_ac013` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_ca001`
--

DROP TABLE IF EXISTS `preparation_2020_06_ca001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_ca001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_ca002`
--

DROP TABLE IF EXISTS `preparation_2020_06_ca002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_ca002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_ca003`
--

DROP TABLE IF EXISTS `preparation_2020_06_ca003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_ca003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_ca004`
--

DROP TABLE IF EXISTS `preparation_2020_06_ca004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_ca004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_cd001`
--

DROP TABLE IF EXISTS `preparation_2020_06_cd001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_cd001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_cd002`
--

DROP TABLE IF EXISTS `preparation_2020_06_cd002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_cd002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_cd003`
--

DROP TABLE IF EXISTS `preparation_2020_06_cd003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_cd003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_cd004`
--

DROP TABLE IF EXISTS `preparation_2020_06_cd004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_cd004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_cl001`
--

DROP TABLE IF EXISTS `preparation_2020_06_cl001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_cl001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_el001`
--

DROP TABLE IF EXISTS `preparation_2020_06_el001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_el001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_el002`
--

DROP TABLE IF EXISTS `preparation_2020_06_el002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_el002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_el003`
--

DROP TABLE IF EXISTS `preparation_2020_06_el003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_el003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_el004`
--

DROP TABLE IF EXISTS `preparation_2020_06_el004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_el004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_el005`
--

DROP TABLE IF EXISTS `preparation_2020_06_el005`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_el005` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_el006`
--

DROP TABLE IF EXISTS `preparation_2020_06_el006`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_el006` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_el007`
--

DROP TABLE IF EXISTS `preparation_2020_06_el007`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_el007` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_el008`
--

DROP TABLE IF EXISTS `preparation_2020_06_el008`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_el008` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_el009`
--

DROP TABLE IF EXISTS `preparation_2020_06_el009`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_el009` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_el010`
--

DROP TABLE IF EXISTS `preparation_2020_06_el010`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_el010` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_el011`
--

DROP TABLE IF EXISTS `preparation_2020_06_el011`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_el011` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_el012`
--

DROP TABLE IF EXISTS `preparation_2020_06_el012`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_el012` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_el013`
--

DROP TABLE IF EXISTS `preparation_2020_06_el013`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_el013` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_el014`
--

DROP TABLE IF EXISTS `preparation_2020_06_el014`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_el014` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_el015`
--

DROP TABLE IF EXISTS `preparation_2020_06_el015`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_el015` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_el016`
--

DROP TABLE IF EXISTS `preparation_2020_06_el016`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_el016` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_el017`
--

DROP TABLE IF EXISTS `preparation_2020_06_el017`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_el017` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_el018`
--

DROP TABLE IF EXISTS `preparation_2020_06_el018`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_el018` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_el019`
--

DROP TABLE IF EXISTS `preparation_2020_06_el019`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_el019` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_el020`
--

DROP TABLE IF EXISTS `preparation_2020_06_el020`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_el020` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_el021`
--

DROP TABLE IF EXISTS `preparation_2020_06_el021`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_el021` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_el022`
--

DROP TABLE IF EXISTS `preparation_2020_06_el022`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_el022` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_el023`
--

DROP TABLE IF EXISTS `preparation_2020_06_el023`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_el023` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_el024`
--

DROP TABLE IF EXISTS `preparation_2020_06_el024`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_el024` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_ga001`
--

DROP TABLE IF EXISTS `preparation_2020_06_ga001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_ga001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_ga002`
--

DROP TABLE IF EXISTS `preparation_2020_06_ga002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_ga002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_ga003`
--

DROP TABLE IF EXISTS `preparation_2020_06_ga003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_ga003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_ga004`
--

DROP TABLE IF EXISTS `preparation_2020_06_ga004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_ga004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_la001`
--

DROP TABLE IF EXISTS `preparation_2020_06_la001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_la001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_la002`
--

DROP TABLE IF EXISTS `preparation_2020_06_la002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_la002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_la003`
--

DROP TABLE IF EXISTS `preparation_2020_06_la003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_la003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_la004`
--

DROP TABLE IF EXISTS `preparation_2020_06_la004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_la004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_na001`
--

DROP TABLE IF EXISTS `preparation_2020_06_na001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_na001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_na002`
--

DROP TABLE IF EXISTS `preparation_2020_06_na002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_na002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_na003`
--

DROP TABLE IF EXISTS `preparation_2020_06_na003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_na003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_na004`
--

DROP TABLE IF EXISTS `preparation_2020_06_na004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_na004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_nt001`
--

DROP TABLE IF EXISTS `preparation_2020_06_nt001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_nt001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_nt002`
--

DROP TABLE IF EXISTS `preparation_2020_06_nt002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_nt002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_nt003`
--

DROP TABLE IF EXISTS `preparation_2020_06_nt003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_nt003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_nt004`
--

DROP TABLE IF EXISTS `preparation_2020_06_nt004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_nt004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_ox001`
--

DROP TABLE IF EXISTS `preparation_2020_06_ox001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_ox001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_ox002`
--

DROP TABLE IF EXISTS `preparation_2020_06_ox002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_ox002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_ox003`
--

DROP TABLE IF EXISTS `preparation_2020_06_ox003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_ox003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_ox004`
--

DROP TABLE IF EXISTS `preparation_2020_06_ox004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_ox004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_st001`
--

DROP TABLE IF EXISTS `preparation_2020_06_st001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_st001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_st002`
--

DROP TABLE IF EXISTS `preparation_2020_06_st002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_st002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_st003`
--

DROP TABLE IF EXISTS `preparation_2020_06_st003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_st003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_st004`
--

DROP TABLE IF EXISTS `preparation_2020_06_st004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_st004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_wa001`
--

DROP TABLE IF EXISTS `preparation_2020_06_wa001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_wa001` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_wa002`
--

DROP TABLE IF EXISTS `preparation_2020_06_wa002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_wa002` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_wa003`
--

DROP TABLE IF EXISTS `preparation_2020_06_wa003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_wa003` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preparation_2020_06_wa004`
--

DROP TABLE IF EXISTS `preparation_2020_06_wa004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation_2020_06_wa004` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `time` datetime NOT NULL,
  `value` double DEFAULT NULL,
  `structure_id` varchar(36) NOT NULL,
  PRIMARY KEY (`time`,`structure_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `process_step_topic`
--

DROP TABLE IF EXISTS `process_step_topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_step_topic` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `process_type` varchar(255) DEFAULT NULL,
  `push_type` varchar(255) DEFAULT NULL,
  `step` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `topic_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `props`
--

DROP TABLE IF EXISTS `props`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `props` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `bsn` varchar(255) DEFAULT NULL,
  `prop` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `spark_feed_variable`
--

DROP TABLE IF EXISTS `spark_feed_variable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spark_feed_variable` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `feed_id` varchar(255) DEFAULT NULL,
  `spark_var` varchar(255) DEFAULT NULL,
  `result_feed_id` varchar(255) DEFAULT NULL,
  `monitor_prop` varchar(255) DEFAULT NULL,
  `variable` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `standard_coal`
--

DROP TABLE IF EXISTS `standard_coal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `standard_coal` (
  `id` varchar(36) NOT NULL,
  `type` varchar(45) DEFAULT NULL COMMENT '类型水water、电当量值electric_equivalent、电等价值electric_equal、蒸汽steam、氮气nitrogen、压缩空气compressed_air',
  `ratio` varchar(45) DEFAULT NULL COMMENT '系数',
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='折标煤表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `station_letter`
--

DROP TABLE IF EXISTS `station_letter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `station_letter` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL COMMENT '站内信标题',
  `content` text COMMENT '内容',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='产量录入副表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_dict`
--

DROP TABLE IF EXISTS `sys_dict`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_dict` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `d_name` varchar(255) DEFAULT NULL,
  `d_property` varchar(255) DEFAULT NULL,
  `d_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `template_factor_item`
--

DROP TABLE IF EXISTS `template_factor_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `template_factor_item` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `compute_value` varchar(255) DEFAULT NULL,
  `feed_value_type` varchar(255) DEFAULT NULL,
  `log_to_feed_name` varchar(255) DEFAULT NULL,
  `operator` varchar(255) DEFAULT NULL,
  `operator_type` varchar(255) DEFAULT NULL,
  `seq` int(11) NOT NULL,
  `template_id` varchar(255) DEFAULT NULL,
  `value` double DEFAULT NULL,
  `feed_id` varchar(36) DEFAULT NULL,
  `input_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKt0h5v70hvsi7w41qft92qwavf` (`feed_id`),
  KEY `FK8v4iknn8l34hbrc9632hb19b3` (`input_id`),
  CONSTRAINT `FK8v4iknn8l34hbrc9632hb19b3` FOREIGN KEY (`input_id`) REFERENCES `input` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FKt0h5v70hvsi7w41qft92qwavf` FOREIGN KEY (`feed_id`) REFERENCES `feed` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `time_interval`
--

DROP TABLE IF EXISTS `time_interval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `time_interval` (
  `id` varchar(36) NOT NULL,
  `start_time` varchar(5) DEFAULT NULL COMMENT '开始时间',
  `end_time` varchar(5) DEFAULT NULL COMMENT '截止时间',
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `pinggu_id` varchar(36) DEFAULT NULL COMMENT '峰平谷尖表关联主键',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='峰平谷尖时间区间';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topic`
--

DROP TABLE IF EXISTS `topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topic` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `topic_desc` varchar(255) DEFAULT NULL,
  `is_del` tinyint(4) NOT NULL,
  `sp_type` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `device_id` varchar(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK9qq4g0jubhblbac5pxp47dk30` (`device_id`),
  CONSTRAINT `FK9qq4g0jubhblbac5pxp47dk30` FOREIGN KEY (`device_id`) REFERENCES `iot_device` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topic_pattern`
--

DROP TABLE IF EXISTS `topic_pattern`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topic_pattern` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `pattern_desc` varchar(255) DEFAULT NULL,
  `is_del` tinyint(4) NOT NULL,
  `sp_type` varchar(255) NOT NULL,
  `pattern_val` varchar(255) NOT NULL,
  `prod_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK9jp9mlppqpxsq7jcf5cxhqu5n` (`prod_id`),
  CONSTRAINT `FK9jp9mlppqpxsq7jcf5cxhqu5n` FOREIGN KEY (`prod_id`) REFERENCES `iot_product` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topologies`
--

DROP TABLE IF EXISTS `topologies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topologies` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `energy` varchar(255) DEFAULT NULL,
  `is_default` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topology_meter_to_props`
--

DROP TABLE IF EXISTS `topology_meter_to_props`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topology_meter_to_props` (
  `prop_id` varchar(36) NOT NULL,
  `topology_meter_id` varchar(36) NOT NULL,
  PRIMARY KEY (`prop_id`,`topology_meter_id`) USING BTREE,
  KEY `FK56m3f9eihrolrau4ols4c5gun` (`topology_meter_id`) USING BTREE,
  CONSTRAINT `FK56m3f9eihrolrau4ols4c5gun` FOREIGN KEY (`topology_meter_id`) REFERENCES `topology_meters` (`id`),
  CONSTRAINT `FKggbacyv2n2fquot387afwpvml` FOREIGN KEY (`prop_id`) REFERENCES `props` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topology_meters`
--

DROP TABLE IF EXISTS `topology_meters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topology_meters` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `sn` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `mainstay_id` varchar(36) DEFAULT NULL,
  `organization_id` varchar(36) DEFAULT NULL,
  `parent_id` varchar(36) DEFAULT NULL,
  `topology_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FKfbhdi2gdwkhv24kbaa2mhhfuj` (`mainstay_id`) USING BTREE,
  KEY `FK4isaee1u1dtb31pnk7nglyf61` (`organization_id`) USING BTREE,
  KEY `FK73jpd4sn2tn0h3s4va9t6vj74` (`parent_id`) USING BTREE,
  KEY `FKcqubq950f2gwyneivp8cd834w` (`topology_id`) USING BTREE,
  CONSTRAINT `FK4isaee1u1dtb31pnk7nglyf61` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`),
  CONSTRAINT `FK73jpd4sn2tn0h3s4va9t6vj74` FOREIGN KEY (`parent_id`) REFERENCES `topology_meters` (`id`),
  CONSTRAINT `FKcqubq950f2gwyneivp8cd834w` FOREIGN KEY (`topology_id`) REFERENCES `topologies` (`id`),
  CONSTRAINT `FKfbhdi2gdwkhv24kbaa2mhhfuj` FOREIGN KEY (`mainstay_id`) REFERENCES `mainstays` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_message`
--

DROP TABLE IF EXISTS `user_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_message` (
  `id` varchar(36) NOT NULL,
  `source_type` varchar(45) DEFAULT NULL COMMENT '消息来源：energy_warning 能耗预警 output_notice 产量录入提醒',
  `message_type` varchar(45) DEFAULT NULL COMMENT '消息类型 exception 异常warning预警notice提醒',
  `state` tinyint(1) DEFAULT '0' COMMENT '是否已读0否1是',
  `user_id` varchar(45) DEFAULT NULL COMMENT '消息接受人唯一标识',
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL COMMENT '消息提示标题',
  `message_id` varchar(36) DEFAULT NULL COMMENT '消息来源的唯一标识',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='折标煤表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `variable_value`
--

DROP TABLE IF EXISTS `variable_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `variable_value` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `modify_time` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `value` double DEFAULT NULL,
  `variable` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `virtual_node_recount`
--

DROP TABLE IF EXISTS `virtual_node_recount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `virtual_node_recount` (
  `id` varchar(36) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `structure_id` varchar(36) DEFAULT NULL COMMENT '真实节点id',
  `change_time` datetime DEFAULT NULL COMMENT '修改数据事件发生的时间',
  `data_time` datetime DEFAULT NULL COMMENT '数据时间',
  `original` double DEFAULT NULL COMMENT '原始值',
  `new_value` double DEFAULT NULL COMMENT '新的修改值',
  `property_code` varchar(10) DEFAULT NULL COMMENT '属性',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='虚拟节点重新计算记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `workshop_yield`
--

DROP TABLE IF EXISTS `workshop_yield`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workshop_yield` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `entry_time` datetime DEFAULT NULL,
  `organization_id` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='产量录入';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `yield`
--

DROP TABLE IF EXISTS `yield`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yield` (
  `id` varchar(36) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `number` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `yield_kind_id` varchar(255) DEFAULT NULL,
  `workshop_yield_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='产量录入副表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `yield_kind`
--

DROP TABLE IF EXISTS `yield_kind`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yield_kind` (
  `id` varchar(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL COMMENT '产量枚举',
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='折标煤表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Current Database: `cm`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `cm` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `cm`;

--
-- Table structure for table `AUDITS`
--

DROP TABLE IF EXISTS `AUDITS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AUDITS` (
  `AUDIT_ID` bigint(20) NOT NULL,
  `SERVICE_ID` bigint(20) DEFAULT NULL,
  `ROLE_ID` bigint(20) DEFAULT NULL,
  `CREATED_INSTANT` bigint(20) DEFAULT NULL,
  `MESSAGE` longtext,
  `ACTING_USER_ID` bigint(20) DEFAULT NULL,
  `COMMAND_ID` bigint(20) DEFAULT NULL,
  `USER_ID` bigint(20) DEFAULT NULL,
  `HOST_ID` bigint(20) DEFAULT NULL,
  `AUDIT_TYPE` varchar(255) NOT NULL DEFAULT 'UNKNOWN',
  `CONFIG_CONTAINER_ID` bigint(20) DEFAULT NULL,
  `CLUSTER_ID` bigint(20) DEFAULT NULL,
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL DEFAULT '0',
  `HOST_TEMPLATE_ID` bigint(20) DEFAULT NULL,
  `IP_ADDRESS` varchar(255) DEFAULT NULL,
  `ALLOWED` tinyint(1) NOT NULL DEFAULT '1',
  `EXTERNAL_ACCOUNT_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`AUDIT_ID`),
  KEY `IDX_AUDIT_CREATED_INSTANT` (`CREATED_INSTANT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CLIENT_CONFIGS`
--

DROP TABLE IF EXISTS `CLIENT_CONFIGS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLIENT_CONFIGS` (
  `CLIENT_CONFIG_ID` bigint(20) NOT NULL,
  `CREATED_INSTANT` bigint(20) NOT NULL,
  `SERVICE_ID` bigint(20) DEFAULT NULL,
  `CONFIG_ARCHIVE` mediumblob NOT NULL,
  `MIME_TYPE` varchar(255) NOT NULL,
  `FILENAME` varchar(255) NOT NULL,
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL DEFAULT '0',
  `CONFIG_STALENESS_STATUS` varchar(255) NOT NULL,
  `METADATA` longtext NOT NULL,
  `GATEWAY_ID` bigint(20) DEFAULT NULL,
  `CLUSTER_ID` bigint(20) DEFAULT NULL,
  `GENERATION` bigint(20) NOT NULL,
  `RESOURCES` longtext,
  PRIMARY KEY (`CLIENT_CONFIG_ID`),
  KEY `FK_CLIENT_CONFIG_SERVICE` (`SERVICE_ID`),
  KEY `IDX_CLIENT_CONFIG_GATEWAY` (`GATEWAY_ID`),
  KEY `IDX_CLIENT_CONFIG_CLUSTER` (`CLUSTER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CLIENT_CONFIGS_TO_HOSTS`
--

DROP TABLE IF EXISTS `CLIENT_CONFIGS_TO_HOSTS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLIENT_CONFIGS_TO_HOSTS` (
  `CLIENT_CONFIG_ID` bigint(20) NOT NULL,
  `HOST_ID` bigint(20) NOT NULL,
  KEY `IDX_CLIENT_CFG2HOST_CLIENT_CFG` (`CLIENT_CONFIG_ID`),
  KEY `IDX_CLIENT_CFG2HOST_HOST` (`HOST_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CLUSTERS`
--

DROP TABLE IF EXISTS `CLUSTERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLUSTERS` (
  `CLUSTER_ID` bigint(20) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `MAINTENANCE_COUNT` int(11) NOT NULL DEFAULT '0',
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL DEFAULT '0',
  `CDH_VERSION` varchar(255) NOT NULL,
  `DISPLAY_NAME` varchar(255) NOT NULL,
  `UUID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`CLUSTER_ID`),
  UNIQUE KEY `NAME` (`NAME`),
  UNIQUE KEY `DISPLAY_NAME` (`DISPLAY_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CLUSTERS_AUD`
--

DROP TABLE IF EXISTS `CLUSTERS_AUD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLUSTERS_AUD` (
  `CLUSTER_ID` bigint(20) NOT NULL,
  `REV` bigint(20) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `CDH_VERSION` varchar(255) DEFAULT NULL,
  `DISPLAY_NAME` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`CLUSTER_ID`,`REV`),
  KEY `FK_CLUSTER_REVISION_START` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CLUSTER_ACTIVATED_RELEASES`
--

DROP TABLE IF EXISTS `CLUSTER_ACTIVATED_RELEASES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLUSTER_ACTIVATED_RELEASES` (
  `CLUSTER_ID` bigint(20) NOT NULL,
  `RELEASE_ID` bigint(20) NOT NULL,
  PRIMARY KEY (`CLUSTER_ID`,`RELEASE_ID`),
  KEY `IDX_CLSTR_ACTV_RLS_CLSTR` (`CLUSTER_ID`),
  KEY `IDX_CLSTR_ACTV_RLS_RLS` (`RELEASE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CLUSTER_ACTIVATED_RELEASES_AUD`
--

DROP TABLE IF EXISTS `CLUSTER_ACTIVATED_RELEASES_AUD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLUSTER_ACTIVATED_RELEASES_AUD` (
  `CLUSTER_ID` bigint(20) NOT NULL,
  `RELEASE_ID` bigint(20) NOT NULL,
  `REV` bigint(20) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`REV`,`CLUSTER_ID`,`RELEASE_ID`),
  KEY `FK_CLUSTER_ACTIVATED_RELEASES_REVISION_START` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CLUSTER_MANAGED_RELEASES`
--

DROP TABLE IF EXISTS `CLUSTER_MANAGED_RELEASES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLUSTER_MANAGED_RELEASES` (
  `CLUSTER_ID` bigint(20) NOT NULL,
  `RELEASE_ID` bigint(20) NOT NULL,
  PRIMARY KEY (`CLUSTER_ID`,`RELEASE_ID`),
  KEY `IDX_CLSTR_MNGD_RLS_CLSTR` (`CLUSTER_ID`),
  KEY `IDX_CLSTR_MNGD_RLS_RLS` (`RELEASE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CLUSTER_UNDISTRIBUTED_RELEASES`
--

DROP TABLE IF EXISTS `CLUSTER_UNDISTRIBUTED_RELEASES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLUSTER_UNDISTRIBUTED_RELEASES` (
  `CLUSTER_ID` bigint(20) NOT NULL,
  `RELEASE_ID` bigint(20) NOT NULL,
  PRIMARY KEY (`CLUSTER_ID`,`RELEASE_ID`),
  KEY `IDX_CLSTR_UNDIST_RLS_CLSTR` (`CLUSTER_ID`),
  KEY `IDX_CLSTR_UNDIST_RLS_RLS` (`RELEASE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CM_PEERS`
--

DROP TABLE IF EXISTS `CM_PEERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CM_PEERS` (
  `PEER_ID` bigint(20) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `URL` varchar(256) NOT NULL,
  `USERNAME` varchar(256) NOT NULL,
  `PASSWORD` varchar(256) NOT NULL,
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL,
  `PEER_TYPE` varchar(255) NOT NULL,
  `CREATED_REMOTE_USER` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`PEER_ID`),
  UNIQUE KEY `IDX_UNIQUE_CM_PEERS` (`NAME`,`PEER_TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CM_VERSION`
--

DROP TABLE IF EXISTS `CM_VERSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CM_VERSION` (
  `VERSION` varchar(256) NOT NULL,
  `GUID` varchar(36) NOT NULL,
  `LAST_UPDATE_INSTANT` bigint(20) DEFAULT NULL,
  `TS` bigint(20) DEFAULT NULL,
  `HOSTNAME` varchar(255) DEFAULT NULL,
  `LAST_ACTIVE_TIMESTAMP` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `COMMANDS`
--

DROP TABLE IF EXISTS `COMMANDS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `COMMANDS` (
  `COMMAND_ID` bigint(20) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `START_INSTANT` bigint(20) DEFAULT NULL,
  `END_INSTANT` bigint(20) DEFAULT NULL,
  `ACTIVE` int(11) DEFAULT NULL,
  `RESULT_MESSAGE` longtext,
  `RESULT_DATA` mediumblob,
  `RESULT_DATA_MIME_TYPE` varchar(255) DEFAULT NULL,
  `RESULT_DATA_FILENAME` varchar(255) DEFAULT NULL,
  `SUCCESS` bit(1) DEFAULT NULL,
  `SERVICE_ID` bigint(20) DEFAULT NULL,
  `ROLE_ID` bigint(20) DEFAULT NULL,
  `PARENT_ID` bigint(20) DEFAULT NULL,
  `HOST_ID` bigint(20) DEFAULT NULL,
  `RESULT_DATA_PATH` varchar(255) DEFAULT NULL,
  `RESULT_DATA_REAPED` bit(1) DEFAULT b'0',
  `CLUSTER_ID` bigint(20) DEFAULT NULL,
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL DEFAULT '0',
  `SCHEDULE_ID` bigint(20) DEFAULT NULL,
  `ARGUMENTS` longtext,
  `AUDITED` bit(1) NOT NULL DEFAULT b'0',
  `FIRST_UPDATED_INSTANT` bigint(20) DEFAULT NULL,
  `CREATION_INSTANT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`COMMAND_ID`),
  KEY `FK_COMMAND_ROLE` (`ROLE_ID`),
  KEY `FK_COMMAND_PARENT` (`PARENT_ID`),
  KEY `FK_COMMAND_SERVICE` (`SERVICE_ID`),
  KEY `FK_COMMAND_HOST` (`HOST_ID`),
  KEY `IDX_COMMAND_ACTIVE` (`ACTIVE`),
  KEY `FK_COMMAND_CLUSTER` (`CLUSTER_ID`),
  KEY `IDX_COMMAND_SCHEDULE` (`SCHEDULE_ID`),
  KEY `IDX_START_INSTANT` (`START_INSTANT`),
  KEY `IDX_COMMAND_STATE` (`STATE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `COMMANDS_DETAIL`
--

DROP TABLE IF EXISTS `COMMANDS_DETAIL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `COMMANDS_DETAIL` (
  `COMMAND_ID` bigint(20) NOT NULL,
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL,
  `INTERNAL_STATE` longblob,
  UNIQUE KEY `COMMAND_ID` (`COMMAND_ID`),
  KEY `IDX_COMMANDS_DETAIL_ID` (`COMMAND_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `COMMAND_SCHEDULES`
--

DROP TABLE IF EXISTS `COMMAND_SCHEDULES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `COMMAND_SCHEDULES` (
  `SPEC_ID` bigint(20) NOT NULL,
  `COMMAND_NAME` varchar(255) NOT NULL,
  `COMMAND_ARGUMENTS` longtext,
  `CLUSTER_ID` bigint(20) DEFAULT NULL,
  `SERVICE_ID` bigint(20) DEFAULT NULL,
  `ROLE_ID` bigint(20) DEFAULT NULL,
  `HOST_ID` bigint(20) DEFAULT NULL,
  `START_TIME` bigint(20) NOT NULL,
  `END_TIME` bigint(20) DEFAULT NULL,
  `REPEAT_INTERVAL` bigint(20) NOT NULL,
  `REPEAT_INTERVAL_UNIT` varchar(255) NOT NULL,
  `PAUSED` bit(1) NOT NULL,
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL,
  `VERSION` bigint(20) NOT NULL,
  `FIRE_AFTER_TIME` bigint(20) DEFAULT NULL,
  `DISPLAY_NAME` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`SPEC_ID`),
  UNIQUE KEY `unique_display_name` (`DISPLAY_NAME`),
  KEY `FK_COMMAND_SCHEDULE_CLUSTER` (`CLUSTER_ID`),
  KEY `FK_COMMAND_SCHEDULE_SERVICE` (`SERVICE_ID`),
  KEY `FK_COMMAND_SCHEDULE_ROLE` (`ROLE_ID`),
  KEY `FK_COMMAND_SCHEDULE_HOST` (`HOST_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CONFIGS`
--

DROP TABLE IF EXISTS `CONFIGS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CONFIGS` (
  `CONFIG_ID` bigint(20) NOT NULL,
  `ROLE_ID` bigint(20) DEFAULT NULL,
  `ATTR` varchar(255) NOT NULL,
  `VALUE` longtext,
  `SERVICE_ID` bigint(20) DEFAULT NULL,
  `HOST_ID` bigint(20) DEFAULT NULL,
  `CONFIG_CONTAINER_ID` bigint(20) DEFAULT NULL,
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL DEFAULT '0',
  `ROLE_CONFIG_GROUP_ID` bigint(20) DEFAULT NULL,
  `CONTEXT` varchar(255) DEFAULT NULL,
  `EXTERNAL_ACCOUNT_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`CONFIG_ID`),
  KEY `FK_CONFIG_ROLE` (`ROLE_ID`),
  KEY `FK_CONFIG_SERVICE` (`SERVICE_ID`),
  KEY `IDX_CONFIG_HOST` (`HOST_ID`),
  KEY `IDX_CONFIG_CONFIG_CONTAINER` (`CONFIG_CONTAINER_ID`),
  KEY `IDX_CONFIG_ROLE_CONFIG_GROUP` (`ROLE_CONFIG_GROUP_ID`),
  KEY `IDX_CONFIG_EXTERNAL_ACCOUNT` (`EXTERNAL_ACCOUNT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CONFIGS_AUD`
--

DROP TABLE IF EXISTS `CONFIGS_AUD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CONFIGS_AUD` (
  `CONFIG_ID` bigint(20) NOT NULL,
  `REV` bigint(20) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `ATTR` varchar(255) DEFAULT NULL,
  `VALUE` longtext,
  `ROLE_ID` bigint(20) DEFAULT NULL,
  `ROLE_CONFIG_GROUP_ID` bigint(20) DEFAULT NULL,
  `SERVICE_ID` bigint(20) DEFAULT NULL,
  `HOST_ID` bigint(20) DEFAULT NULL,
  `CONFIG_CONTAINER_ID` bigint(20) DEFAULT NULL,
  `EXTERNAL_ACCOUNT_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`CONFIG_ID`,`REV`),
  KEY `FK_CONFIG_REVISION_START` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CONFIG_CONTAINERS`
--

DROP TABLE IF EXISTS `CONFIG_CONTAINERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CONFIG_CONTAINERS` (
  `CONFIG_CONTAINER_ID` bigint(20) NOT NULL,
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL DEFAULT '0',
  `CONFIG_TYPE` varchar(255) NOT NULL,
  `CONFIG_GENERATION` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`CONFIG_CONTAINER_ID`),
  UNIQUE KEY `CONFIG_TYPE` (`CONFIG_TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CREDENTIALS`
--

DROP TABLE IF EXISTS `CREDENTIALS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CREDENTIALS` (
  `CREDENTIAL_ID` bigint(20) NOT NULL,
  `PRINCIPAL` varchar(255) NOT NULL,
  `KEYTAB` mediumblob NOT NULL,
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`CREDENTIAL_ID`),
  UNIQUE KEY `PRINCIPAL` (`PRINCIPAL`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `DIAGNOSTICS_EVENTS`
--

DROP TABLE IF EXISTS `DIAGNOSTICS_EVENTS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DIAGNOSTICS_EVENTS` (
  `EVENT_ID` bigint(20) NOT NULL,
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL DEFAULT '0',
  `EVENT_NAME` varchar(64) NOT NULL,
  `EVENT_TYPE` varchar(32) NOT NULL,
  `EVENT_TIME` bigint(20) NOT NULL,
  `DETAILS` mediumtext,
  PRIMARY KEY (`EVENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EXTERNAL_ACCOUNTS`
--

DROP TABLE IF EXISTS `EXTERNAL_ACCOUNTS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EXTERNAL_ACCOUNTS` (
  `EXTERNAL_ACCOUNT_ID` bigint(20) NOT NULL,
  `TYPE_NAME` varchar(255) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `DISPLAY_NAME` varchar(255) NOT NULL,
  `CREATED_INSTANT` bigint(20) NOT NULL,
  `LAST_MODIFIED_INSTANT` bigint(20) NOT NULL,
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`EXTERNAL_ACCOUNT_ID`),
  UNIQUE KEY `UNIQUE_EXTERNAL_ACCOUNTS_NAME` (`NAME`),
  UNIQUE KEY `UNIQUE_EXTERNAL_ACCOUNTS_DISPLAY_NAME` (`DISPLAY_NAME`),
  KEY `IDX_EXTERNAL_ACCOUNTS_TYPE_NAME` (`TYPE_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EXTERNAL_ACCOUNTS_AUD`
--

DROP TABLE IF EXISTS `EXTERNAL_ACCOUNTS_AUD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EXTERNAL_ACCOUNTS_AUD` (
  `EXTERNAL_ACCOUNT_ID` bigint(20) NOT NULL,
  `REV` bigint(20) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `TYPE_NAME` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `DISPLAY_NAME` varchar(255) DEFAULT NULL,
  `CREATED_INSTANT` bigint(20) DEFAULT NULL,
  `LAST_MODIFIED_INSTANT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`EXTERNAL_ACCOUNT_ID`,`REV`),
  KEY `IDX_REV` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `GLOBAL_SETTINGS`
--

DROP TABLE IF EXISTS `GLOBAL_SETTINGS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GLOBAL_SETTINGS` (
  `GLOBAL_SETTING_ID` bigint(20) NOT NULL,
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL DEFAULT '0',
  `ATTR` varchar(255) NOT NULL,
  `VALUE` longtext NOT NULL,
  PRIMARY KEY (`GLOBAL_SETTING_ID`),
  UNIQUE KEY `IDX_UNIQUE_GLOBAL_SETTING` (`ATTR`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HOSTS`
--

DROP TABLE IF EXISTS `HOSTS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HOSTS` (
  `HOST_ID` bigint(20) NOT NULL,
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL DEFAULT '0',
  `HOST_IDENTIFIER` varchar(255) NOT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `IP_ADDRESS` varchar(255) DEFAULT NULL,
  `RACK_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `CONFIG_CONTAINER_ID` bigint(20) DEFAULT NULL,
  `MAINTENANCE_COUNT` int(11) NOT NULL DEFAULT '0',
  `DECOMMISSION_COUNT` int(11) NOT NULL DEFAULT '0',
  `CLUSTER_ID` bigint(20) DEFAULT NULL,
  `NUM_CORES` bigint(20) DEFAULT NULL,
  `TOTAL_PHYS_MEM_BYTES` bigint(20) DEFAULT NULL,
  `PUBLIC_NAME` varchar(255) DEFAULT NULL,
  `PUBLIC_IP_ADDRESS` varchar(255) DEFAULT NULL,
  `CLOUD_PROVIDER` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`HOST_ID`),
  UNIQUE KEY `HOST_IDENTIFIER` (`HOST_IDENTIFIER`),
  KEY `IDX_HOST_CONFIG_CONTAINER` (`CONFIG_CONTAINER_ID`),
  KEY `IDX_HOST_CLUSTER` (`CLUSTER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HOSTS_AUD`
--

DROP TABLE IF EXISTS `HOSTS_AUD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HOSTS_AUD` (
  `HOST_ID` bigint(20) NOT NULL,
  `REV` bigint(20) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `HOST_IDENTIFIER` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `CLUSTER_ID` bigint(20) DEFAULT NULL,
  `CONFIG_CONTAINER_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`HOST_ID`,`REV`),
  KEY `FK_HOST_REVISION_START` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HOST_TEMPLATES`
--

DROP TABLE IF EXISTS `HOST_TEMPLATES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HOST_TEMPLATES` (
  `HOST_TEMPLATE_ID` bigint(20) NOT NULL,
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `CLUSTER_ID` bigint(20) NOT NULL,
  PRIMARY KEY (`HOST_TEMPLATE_ID`),
  UNIQUE KEY `NAME` (`NAME`),
  KEY `IDX_HOST_TEMPLATE_CLUSTER` (`CLUSTER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `HOST_TEMPLATE_TO_ROLE_CONF_GRP`
--

DROP TABLE IF EXISTS `HOST_TEMPLATE_TO_ROLE_CONF_GRP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HOST_TEMPLATE_TO_ROLE_CONF_GRP` (
  `HOST_TEMPLATE_ID` bigint(20) NOT NULL,
  `ROLE_CONFIG_GROUP_ID` bigint(20) NOT NULL,
  PRIMARY KEY (`HOST_TEMPLATE_ID`,`ROLE_CONFIG_GROUP_ID`),
  KEY `IDX_HOST_TEMPL_TO_RCG_HOST_TMP` (`HOST_TEMPLATE_ID`),
  KEY `IDX_HOST_TEMPL_TO_RCG_RCG` (`ROLE_CONFIG_GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `METRICS`
--

DROP TABLE IF EXISTS `METRICS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `METRICS` (
  `METRIC_ID` bigint(20) NOT NULL,
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL,
  `METRIC_IDENTIFIER` bigint(20) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `METRIC` longtext,
  PRIMARY KEY (`METRIC_ID`),
  UNIQUE KEY `METRIC_IDENTIFIER` (`METRIC_IDENTIFIER`),
  UNIQUE KEY `NAME` (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PARCELS`
--

DROP TABLE IF EXISTS `PARCELS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PARCELS` (
  `PARCEL_ID` bigint(20) NOT NULL,
  `PRODUCT` varchar(255) NOT NULL,
  `VERSION` varchar(255) NOT NULL,
  `OS` varchar(255) NOT NULL,
  `FILENAME` varchar(255) NOT NULL,
  `HASH` varchar(255) DEFAULT NULL,
  `BINARY_DIFF` bit(1) DEFAULT NULL,
  `STATUS` varchar(255) NOT NULL,
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL DEFAULT '0',
  `SOURCE` varchar(4000) DEFAULT NULL,
  `RELEASE_INSTANT` bigint(20) DEFAULT NULL,
  `DOWNLOAD_INSTANT` bigint(20) DEFAULT NULL,
  `RELEASE_ID` bigint(20) NOT NULL,
  PRIMARY KEY (`PARCEL_ID`),
  UNIQUE KEY `FILENAME` (`FILENAME`),
  KEY `IDX_PARCEL_RELEASE` (`RELEASE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PARCEL_COMPONENTS`
--

DROP TABLE IF EXISTS `PARCEL_COMPONENTS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PARCEL_COMPONENTS` (
  `PARCEL_ID` bigint(20) NOT NULL,
  `VERSION` varchar(255) NOT NULL,
  `COMPONENT_NAME` varchar(255) NOT NULL,
  PRIMARY KEY (`PARCEL_ID`,`COMPONENT_NAME`),
  KEY `IDX_COMPONENT_PARCEL` (`PARCEL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PROCESSES`
--

DROP TABLE IF EXISTS `PROCESSES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROCESSES` (
  `PROCESS_ID` bigint(20) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `ROLE_ID` bigint(20) DEFAULT NULL,
  `COMMAND_ID` bigint(20) DEFAULT NULL,
  `HOST_ID` bigint(20) NOT NULL,
  `PROCESS_USER` varchar(255) DEFAULT NULL,
  `PROCESS_GROUP` varchar(255) DEFAULT NULL,
  `PROGRAM` varchar(255) DEFAULT NULL,
  `ARGUMENTS` longtext,
  `RUNNING` bit(1) DEFAULT NULL,
  `RUN_GENERATION` bigint(20) DEFAULT NULL,
  `ONE_OFF` bit(1) DEFAULT NULL,
  `STATUS_LINKS` longtext,
  `RESOURCES` longtext,
  `ENVIRONMENT` longtext,
  `CREATED_INSTANT` bigint(20) NOT NULL DEFAULT '0',
  `SPECIAL_FILE_INFO` longtext,
  `AUTO_RESTART` bit(1) NOT NULL DEFAULT b'1',
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL DEFAULT '0',
  `UPDATED_INSTANT` bigint(20) NOT NULL,
  `REQUIRED_PARCEL_TAGS` longtext NOT NULL,
  `OPTIONAL_PARCEL_TAGS` longtext NOT NULL,
  `CONFIG_GENERATION` bigint(20) NOT NULL,
  `EXTRA_GROUPS` longtext NOT NULL,
  `START_SECS` int(11) DEFAULT NULL,
  PRIMARY KEY (`PROCESS_ID`),
  KEY `FK_PROCESS_HOST` (`HOST_ID`),
  KEY `FK_PROCESS_ROLE` (`ROLE_ID`),
  KEY `FK_PROCESS_COMMAND` (`COMMAND_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PROCESSES_DETAIL`
--

DROP TABLE IF EXISTS `PROCESSES_DETAIL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROCESSES_DETAIL` (
  `PROCESS_ID` bigint(20) NOT NULL,
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL,
  `CONFIGURATION_DATA` mediumblob,
  `REFRESH_FILES` longtext,
  UNIQUE KEY `PROCESS_ID` (`PROCESS_ID`),
  KEY `IDX_PROCESSES_DETAIL_ID` (`PROCESS_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PROCESS_ACTIVE_RELEASES`
--

DROP TABLE IF EXISTS `PROCESS_ACTIVE_RELEASES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROCESS_ACTIVE_RELEASES` (
  `PROCESS_ID` bigint(20) NOT NULL,
  `RELEASE_ID` bigint(20) NOT NULL,
  PRIMARY KEY (`PROCESS_ID`,`RELEASE_ID`),
  KEY `IDX_PROC_ACTV_RLS_PROC` (`PROCESS_ID`),
  KEY `IDX_PROC_ACTV_RLS_RLS` (`RELEASE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RELEASES`
--

DROP TABLE IF EXISTS `RELEASES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `RELEASES` (
  `RELEASE_ID` bigint(20) NOT NULL,
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL,
  `PRODUCT` varchar(255) NOT NULL,
  `VERSION` varchar(255) NOT NULL,
  `RELEASE_NOTES` longtext,
  `DEPENDS` longtext,
  `CONFLICTS` longtext,
  `REPLACES` longtext,
  `SERVICES_RESTART_INFO` mediumblob,
  PRIMARY KEY (`RELEASE_ID`),
  UNIQUE KEY `IDX_UNIQUE_RELEASE` (`PRODUCT`,`VERSION`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `RELEASES_AUD`
--

DROP TABLE IF EXISTS `RELEASES_AUD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `RELEASES_AUD` (
  `RELEASE_ID` bigint(20) NOT NULL,
  `REV` bigint(20) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `PRODUCT` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`RELEASE_ID`,`REV`),
  KEY `FK_RELEASE_REVISION_START` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `REVISIONS`
--

DROP TABLE IF EXISTS `REVISIONS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REVISIONS` (
  `REVISION_ID` bigint(20) NOT NULL,
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL,
  `USER_ID` bigint(20) DEFAULT NULL,
  `TIMESTAMP` bigint(20) DEFAULT NULL,
  `MESSAGE` longtext,
  PRIMARY KEY (`REVISION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ROLES`
--

DROP TABLE IF EXISTS `ROLES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ROLES` (
  `ROLE_ID` bigint(20) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `HOST_ID` bigint(20) NOT NULL,
  `ROLE_TYPE` varchar(255) NOT NULL,
  `CONFIGURED_STATUS` varchar(255) NOT NULL,
  `SERVICE_ID` bigint(20) DEFAULT NULL,
  `MERGED_KEYTAB` mediumblob,
  `MAINTENANCE_COUNT` int(11) NOT NULL DEFAULT '0',
  `DECOMMISSION_COUNT` int(11) NOT NULL DEFAULT '0',
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL DEFAULT '0',
  `ROLE_CONFIG_GROUP_ID` bigint(20) NOT NULL,
  `HAS_EVER_STARTED` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ROLE_ID`),
  UNIQUE KEY `NAME` (`NAME`),
  KEY `FK_ROLE_HOST` (`HOST_ID`),
  KEY `FK_ROLE_SERVICE` (`SERVICE_ID`),
  KEY `FK_ROLE_ROLE_CONFIG_GROUP` (`ROLE_CONFIG_GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ROLES_AUD`
--

DROP TABLE IF EXISTS `ROLES_AUD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ROLES_AUD` (
  `ROLE_ID` bigint(20) NOT NULL,
  `REV` bigint(20) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `ROLE_TYPE` varchar(255) DEFAULT NULL,
  `HOST_ID` bigint(20) DEFAULT NULL,
  `SERVICE_ID` bigint(20) DEFAULT NULL,
  `ROLE_CONFIG_GROUP_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ROLE_ID`,`REV`),
  KEY `FK_ROLE_REVISION_START` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ROLE_CONFIG_GROUPS`
--

DROP TABLE IF EXISTS `ROLE_CONFIG_GROUPS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ROLE_CONFIG_GROUPS` (
  `ROLE_CONFIG_GROUP_ID` bigint(20) NOT NULL,
  `ROLE_TYPE` varchar(255) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL DEFAULT '0',
  `BASE` bit(1) NOT NULL DEFAULT b'0',
  `DISPLAY_NAME` varchar(255) NOT NULL,
  `SERVICE_ID` bigint(20) NOT NULL,
  PRIMARY KEY (`ROLE_CONFIG_GROUP_ID`),
  UNIQUE KEY `IDX_UNIQUE_ROLE_CONFIG_GROUP` (`NAME`),
  UNIQUE KEY `IDX_UNIQUE_RCG_DISP` (`DISPLAY_NAME`,`SERVICE_ID`),
  KEY `FK_ROLE_CONFIG_GROUP_SERVICE` (`SERVICE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ROLE_CONFIG_GROUPS_AUD`
--

DROP TABLE IF EXISTS `ROLE_CONFIG_GROUPS_AUD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ROLE_CONFIG_GROUPS_AUD` (
  `ROLE_CONFIG_GROUP_ID` bigint(20) NOT NULL,
  `REV` bigint(20) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `ROLE_TYPE` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `DISPLAY_NAME` varchar(255) DEFAULT NULL,
  `BASE` tinyint(1) DEFAULT NULL,
  `SERVICE_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ROLE_CONFIG_GROUP_ID`,`REV`),
  KEY `FK_RCG_REVISION_START` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ROLE_STALENESS_STATUS`
--

DROP TABLE IF EXISTS `ROLE_STALENESS_STATUS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ROLE_STALENESS_STATUS` (
  `ROLE_ID` bigint(20) NOT NULL,
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL,
  `STATUS` varchar(255) NOT NULL,
  KEY `IDX_ROLE_STALENESS_STATUS_ID` (`ROLE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SCHEMA_VERSION`
--

DROP TABLE IF EXISTS `SCHEMA_VERSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SCHEMA_VERSION` (
  `VERSION` int(11) NOT NULL,
  `OLD_VERSION` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SERVICES`
--

DROP TABLE IF EXISTS `SERVICES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SERVICES` (
  `SERVICE_ID` bigint(20) NOT NULL,
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL DEFAULT '0',
  `NAME` varchar(255) NOT NULL,
  `SERVICE_TYPE` varchar(255) DEFAULT NULL,
  `CLUSTER_ID` bigint(20) DEFAULT NULL,
  `MAINTENANCE_COUNT` int(11) NOT NULL DEFAULT '0',
  `DISPLAY_NAME` varchar(255) NOT NULL,
  `GENERATION` bigint(20) NOT NULL,
  PRIMARY KEY (`SERVICE_ID`),
  UNIQUE KEY `NAME` (`NAME`),
  UNIQUE KEY `IDX_UNIQUE_SERVICE` (`CLUSTER_ID`,`DISPLAY_NAME`),
  KEY `FK_SERVICE_CLUSTER` (`CLUSTER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SERVICES_AUD`
--

DROP TABLE IF EXISTS `SERVICES_AUD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SERVICES_AUD` (
  `SERVICE_ID` bigint(20) NOT NULL,
  `REV` bigint(20) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `SERVICE_TYPE` varchar(255) DEFAULT NULL,
  `CLUSTER_ID` bigint(20) DEFAULT NULL,
  `DISPLAY_NAME` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`SERVICE_ID`,`REV`),
  KEY `FK_SERVICE_REVISION_START` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SNAPSHOT_POLICIES`
--

DROP TABLE IF EXISTS `SNAPSHOT_POLICIES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SNAPSHOT_POLICIES` (
  `POLICY_ID` bigint(20) NOT NULL,
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL,
  `POLICY_IDENTIFIER` varchar(255) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `DESCRIPTION` longtext,
  `SERVICE_ID` bigint(20) NOT NULL,
  `SCHEDULE_ID` bigint(20) NOT NULL,
  `HOURLY_SNAPSHOTS` bigint(20) NOT NULL,
  `DAILY_SNAPSHOTS` bigint(20) NOT NULL,
  `WEEKLY_SNAPSHOTS` bigint(20) NOT NULL,
  `MONTHLY_SNAPSHOTS` bigint(20) NOT NULL,
  `YEARLY_SNAPSHOTS` bigint(20) NOT NULL,
  `MINUTE_OF_HOUR` tinyint(4) NOT NULL,
  `HOUR_OF_DAY` tinyint(4) NOT NULL,
  `DAY_OF_WEEK` tinyint(4) NOT NULL,
  `DAY_OF_MONTH` tinyint(4) NOT NULL,
  `MONTH_OF_YEAR` tinyint(4) NOT NULL,
  `HOURS_LIST` longtext,
  `ENTITIES_TO_SNAPSHOT` longtext,
  `ALERT_ON_START` bit(1) NOT NULL,
  `ALERT_ON_SUCCESS` bit(1) NOT NULL,
  `ALERT_ON_FAIL` bit(1) NOT NULL,
  `ALERT_ON_ABORT` bit(1) NOT NULL,
  `PAUSED` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`POLICY_ID`),
  UNIQUE KEY `POLICY_IDENTIFIER` (`POLICY_IDENTIFIER`),
  UNIQUE KEY `SCHEDULE_ID` (`SCHEDULE_ID`),
  UNIQUE KEY `IDX_UNIQUE_SP_NAME_SERVICE` (`NAME`,`SERVICE_ID`),
  KEY `FK_SNAPSHOT_POLICY_SERVICE` (`SERVICE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `USERS`
--

DROP TABLE IF EXISTS `USERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USERS` (
  `USER_ID` bigint(20) NOT NULL,
  `USER_NAME` varchar(255) NOT NULL,
  `PASSWORD_HASH` varchar(255) NOT NULL,
  `PASSWORD_SALT` bigint(20) NOT NULL,
  `PASSWORD_LOGIN` tinyint(1) NOT NULL,
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`USER_ID`),
  UNIQUE KEY `unique_user_name` (`USER_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `USER_ROLES`
--

DROP TABLE IF EXISTS `USER_ROLES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_ROLES` (
  `USER_ROLE_ID` bigint(20) NOT NULL,
  `USER_ID` bigint(20) NOT NULL,
  `USER_ROLE` varchar(255) NOT NULL,
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`USER_ROLE_ID`),
  KEY `FK_USER_ROLE` (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `USER_SETTINGS`
--

DROP TABLE IF EXISTS `USER_SETTINGS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_SETTINGS` (
  `USER_SETTING_ID` bigint(20) NOT NULL,
  `USER_ID` bigint(20) NOT NULL,
  `ATTR` varchar(255) NOT NULL,
  `VALUE` longtext NOT NULL,
  `OPTIMISTIC_LOCK_VERSION` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`USER_SETTING_ID`),
  UNIQUE KEY `USER_ID` (`USER_ID`,`ATTR`),
  KEY `FK_USER_SETTING_USER` (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-18  8:37:53
